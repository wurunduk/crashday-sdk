// ==================================================================
//
//   p3dmanag2.cpp - Freie Funktionen, die das Laden und Speichern
//                   von P3D-ObjectFiles managen, f�r die Version 2
//
//   Autor:    Robert Clemens
//   Start:    10.05.03
//
// ==================================================================

#include "p3dmanag2.hpp"                               // Headerfile mit Klassendeklaration

#include <io.h>             // Header fuer 'access'
#include <stdio.h>          // Dateioperationen
#include <stdlib.h>         // '_fmode'
#include <direct.h>         // F�r Directories
#include <fcntl.h>          // 'O_BINARY'
#include <i86.h>            // sound
#include <windows.h>            // sound




// Extern verf�gbare Variablen
MESHCOUNT     P3DNumMeshes = 0;                         // Anzahl von Meshmodels
MESHCOUNT     P3DNumMeshesAllocated = 0;                // Anzahl von allokierten Meshmodels
P3DMESH*      P3DMesh = NULL;                           // Mesh-Daten

LIGHTCOUNT    P3DNumLights = 0;                         // Lichtern im Objekt
P3DLIGHT      P3DLight[P3DMANAG_MAXLIGHTS];             // Lichterdaten

P3DTEXID      P3DNumTextures = 0;                       // Anzahl an verschiedenen Texturen
RENDERINFO    P3DRenderInfo[P3DMANAG_MAXTEXTURES];      // Daten von Texturen und Materialien

P3DVALUE      P3DLength = 0;                            // Objektma�e
P3DVALUE      P3DDepth = 0;
P3DVALUE      P3DHeight = 0;

int           P3DUserDataSize = 0;                     // Zus�tzliche Userdaten
char*         P3DUserDataPtr = NULL;




// PrepareNewP3DMeshData ( alte P3D-Meshdaten l�schen und neue P3D mit bestimmter Anzahl an Meshes vorbereiten )
// =============================================================================================================

void PrepareNewP3DMeshData( MESHCOUNT maxmeshes )
{

    if( P3DNumMeshesAllocated > 0 )             // Wenn vorher ein Modell geladen...
    {
        // Alte Sachen l�schen
        for( int i = 0; i < P3DNumMeshesAllocated; i++ )
        { 
            if( P3DMesh[i].Vertex != NULL ){ delete [] P3DMesh[i].Vertex; P3DMesh[i].Vertex = NULL; }
            if( P3DMesh[i].Poly != NULL ){ delete [] P3DMesh[i].Poly; P3DMesh[i].Poly = NULL; }
            if( P3DMesh[i].SavePoly != NULL ){ delete [] P3DMesh[i].SavePoly; P3DMesh[i].SavePoly = NULL; }
        }

        delete [] P3DMesh;
        P3DMesh = NULL;
        P3DNumMeshes = 0;
        P3DNumMeshesAllocated = 0;
    }


    P3DNumMeshesAllocated = maxmeshes;                // Anzahl von maximal m�glichen Meshmodels vermerken
    P3DNumMeshes = 0;
    P3DMesh = new P3DMESH[ maxmeshes ];


    if( P3DMesh == NULL )
    {
       _ERROR_M( "Out of memory! Mesh allocation failed!\n", maxmeshes );
    }
    
    for( int i = 0; i < P3DNumMeshesAllocated; i++ )
    {
        P3DMesh[i].NumPolys = 0;                // Restliche Meshparameter werden dann normalerweise von Loadingfkts.
        P3DMesh[i].NumVertices = 0;             // gesetzt
        P3DMesh[i].NumPolysAllocated = 0;
        P3DMesh[i].NumVerticesAllocated = 0;
        P3DMesh[i].Vertex = NULL;
        P3DMesh[i].Poly = NULL;
        P3DMesh[i].SavePoly = NULL;
    }
}



// PrepareMeshVertices ( allokiere Speicher f�r die Vertices eines Meshes )
// ========================================================================

void PrepareMeshVertices( MESHCOUNT mesh, VERTEXCOUNT maxverts )
{

   _ASSERT( P3DNumMeshesAllocated > mesh );      // Mesh number value must be valid
   _ASSERT( maxverts <= P3DMANAG_MAXVERTICES );

    // Delete previous mesh vertex data (if available)
    if( P3DMesh[mesh].Vertex != NULL )
    {
        delete [] P3DMesh[mesh].Vertex;
        P3DMesh[mesh].Vertex = NULL;
        P3DMesh[mesh].NumVerticesAllocated = 0;
        P3DMesh[mesh].NumVertices = 0;
    }


    P3DMesh[mesh].NumVerticesAllocated = maxverts;
    P3DMesh[mesh].NumVertices = 0;
    P3DMesh[mesh].Vertex = new P3DVERTEX[ maxverts ];
    
    if( P3DMesh[mesh].Vertex == NULL )
    {
       _ERROR_M( "Out of memory! Mesh allocation failed!\nProbably too high vertex count !", maxverts );
    }
}



// PrepareMeshPolys ( allokiere Speicher f�r die Polys eines Meshes )
// ==================================================================

void PrepareMeshPolys( MESHCOUNT mesh, VERTEXCOUNT maxpolys )
{

   _ASSERT( P3DNumMeshesAllocated > mesh );      // Mesh number value must be valid
   _ASSERT( maxpolys <= P3DMANAG_MAXPOLYS );

    // Delete previous mesh poly data (if available)
    if( P3DMesh[mesh].Poly != NULL )
    {
        delete [] P3DMesh[mesh].Poly;
        delete [] P3DMesh[mesh].SavePoly;
        P3DMesh[mesh].Poly = NULL;
        P3DMesh[mesh].SavePoly = NULL;

        P3DMesh[mesh].NumPolysAllocated = 0;
        P3DMesh[mesh].NumPolys = 0;
    }


    P3DMesh[mesh].NumPolysAllocated = maxpolys;
    P3DMesh[mesh].NumPolys = 0;
    P3DMesh[mesh].Poly = new P3DTEXPOLYGON[ maxpolys ];
    P3DMesh[mesh].SavePoly = new SAVEPOLYGON[ maxpolys ];


    if( P3DMesh[mesh].Poly == NULL ||
        P3DMesh[mesh].SavePoly == NULL )
    {
       _ERROR_M( "Out of memory! Mesh allocation failed!\nProbably too high polygon count !", maxpolys );
    }
}



// IsTextureInList ( liefert 1, wenn sich eine Textur im P3DRenderInfo befindet )
// ===========================================================================

char IsTextureInList( String filename )
{

    for( int i = 0; i < P3DNumTextures; i++ )
    {
        if( P3DRenderInfo[i].TextureFile == filename ){ return 1; }
    }

    return 0;  // Nichts da
}



// GetTextureID ( liefert den Index der Textur im P3DRenderInfo )
// ===========================================================

P3DTEXID GetTextureID( String filename )
{

    for( int i = 0; i < P3DNumTextures; i++ )
    {
        if( P3DRenderInfo[i].TextureFile == filename ){ return i; }
    }

   _ERROR_M( "Error in P3D library!\nTexture ID could not be found in P3DRenderInfo", filename );
    return 0;
}



// AddTextureToList ( f�gt eine Textur in das P3DRenderInfo ein )
// ===========================================================

P3DTEXID AddTextureToList( String filename )
{

    P3DNumTextures++;

    P3DRenderInfo[P3DNumTextures-1].TextureFile = filename.lower();

    // Setze die Texturverwendung in allen Meshes auf 0
    for( int i = 0; i < P3DNumMeshes; i++ )
    {
       P3DMesh[i].TextureInfo[P3DNumTextures-1].NumFlat = 0;
       P3DMesh[i].TextureInfo[P3DNumTextures-1].NumFlatMetal = 0;
       P3DMesh[i].TextureInfo[P3DNumTextures-1].NumGouraud = 0;
       P3DMesh[i].TextureInfo[P3DNumTextures-1].NumGouraudMetal = 0;
       P3DMesh[i].TextureInfo[P3DNumTextures-1].NumGouraudMetalEnv = 0;
       P3DMesh[i].TextureInfo[P3DNumTextures-1].NumShining = 0;
    }

    return P3DNumTextures-1;
}



// PutToSavePoly ( �bertr�gt ein P3DTEXPOLY in die SavePoly-Struktur )
// ===================================================================

void PutToSavePoly( MESHCOUNT mesh, POLYGONCOUNT src, POLYGONCOUNT dst )
{
    P3DMesh[mesh].SavePoly[dst].P1 = P3DMesh[mesh].Poly[src].P1;
    P3DMesh[mesh].SavePoly[dst].P2 = P3DMesh[mesh].Poly[src].P2;
    P3DMesh[mesh].SavePoly[dst].P3 = P3DMesh[mesh].Poly[src].P3;

    P3DMesh[mesh].SavePoly[dst].U1 = P3DMesh[mesh].Poly[src].U1;
    P3DMesh[mesh].SavePoly[dst].V1 = P3DMesh[mesh].Poly[src].V1;

    P3DMesh[mesh].SavePoly[dst].U2 = P3DMesh[mesh].Poly[src].U2;
    P3DMesh[mesh].SavePoly[dst].V2 = P3DMesh[mesh].Poly[src].V2;

    P3DMesh[mesh].SavePoly[dst].U3 = P3DMesh[mesh].Poly[src].U3;
    P3DMesh[mesh].SavePoly[dst].V3 = P3DMesh[mesh].Poly[src].V3;
}



int  LoadP3DFileV1( FILE* fp );

// LoadP3DFile ( l�dt eine Modelldatei in die P3D-Struktur )
// =========================================================

int LoadP3DFile( String filename )
{

   if( access( filename, F_OK ) != 0 )  // Datei nicht vorhanden
   {
       return -1;
   }
   

   // Alten Userspeicher freigeben
   if( P3DUserDataPtr != NULL ){ delete [] P3DUserDataPtr; }
   P3DUserDataPtr = NULL;
   P3DUserDataSize = 0;
   

   // Datei �ffnen
  _fmode = O_BINARY;
   FILE* fp = fopen( filename, "r" ); 


   char  TempChar;      // Tempor�re Variablen
   short TempShort;
   char  TempBuf[256];
   char  P3D[3];
   int   ByteCounter;
   int   LastFSeekPos;



   // "P3D"-Zeichen-Test
   fread( &P3D[0], 1, 3, fp );  
   if( P3D[0] != 'P' || P3D[1] != '3' || P3D[2] != 'D' )   
   {
         return -1;
   }


   // Versionstest ( nur V.1 unterst�tzt )
   fread( &TempChar, 1, 1, fp );
   if( TempChar != P3D_FILEVERSION )   
   {
       if( TempChar == 1 )              // Das ist die alte Version
       {
           int RetVal = LoadP3DFileV1( fp );
           fclose( fp );

           return RetVal;
       }
       else
       {
           return -1;
       }
   }


   fread( &P3DLength, 4, 1, fp );       // Schreibe Objektma�e
   fread( &P3DHeight, 4, 1, fp );
   fread( &P3DDepth, 4, 1, fp );


   // "TEX"-Zeichen-Test
   fread( &TempBuf[0], 1, 3, fp );  
   if( TempBuf[0] != 'T' || TempBuf[1] != 'E' || TempBuf[2] != 'X' )   
   {
         return -1;
   }

   fseek( fp, 4, SEEK_CUR );            // Bytezahl �berspringen


   // Lies Texturinfos
   fread( &P3DNumTextures, 1, 1, fp );
  _ASSERT( P3DNumTextures > 0 );

   for( int i = 0; i < P3DNumTextures; i++ )  
   {
       // Lies kompletten Texturnamen (+ '\0')
       bzero( &TempBuf[0], 255 );
       for( int a = 0; ; a++ )
       {
           TempBuf[a] = fgetc( fp );
           if( TempBuf[a] == 0 ){ break; }
       }

       P3DRenderInfo[i].TextureFile = &TempBuf[0];
       P3DRenderInfo[i].TextureFile.lower();
   }


   // "LIGHTS"-Zeichen-Test
   fread( &TempBuf[0], 1, 6, fp );  
   if( TempBuf[0] != 'L' || TempBuf[1] != 'I' || TempBuf[2] != 'G' ||
       TempBuf[3] != 'H' || TempBuf[4] != 'T' || TempBuf[5] != 'S' )
   {
         return -1;
   }

   fseek( fp, 4, SEEK_CUR );            // Bytezahl �berspringen


   // Lies Lichtdaten
   fread( &P3DNumLights, 2, 1, fp );

   for( i = 0; i < P3DNumLights; i++ )  
   {
       // Lichtname
       bzero( &TempBuf[0], 255 );
       for( int a = 0; ; a++ )
       {
           TempBuf[a] = fgetc( fp );
           if( TempBuf[a] == 0 ){ break; }
       }

       P3DLight[i].Name = &TempBuf[0];

       fread( &P3DLight[i].Pos.X, 4, 1, fp );              // Lichtposition
       fread( &P3DLight[i].Pos.Y, 4, 1, fp );   
       fread( &P3DLight[i].Pos.Z, 4, 1, fp );   

       fread( &P3DLight[i].Range, 4, 1, fp );              // Radius
       fread( &P3DLight[i].Color, 4, 1, fp );              // Farbe

       fread( &P3DLight[i].ShowCorona, 1, 1, fp );         // Zeige Coronas?
       fread( &P3DLight[i].ShowLensFlares, 1, 1, fp );     // Zeige LensFlares?
       fread( &P3DLight[i].LightUpEnvironment, 1, 1, fp ); // Strahle Licht aus?
   }



   // "MESHES"-Zeichen-Test
   fread( &TempBuf[0], 1, 6, fp );  
   if( TempBuf[0] != 'M' || TempBuf[1] != 'E' || TempBuf[2] != 'S' ||
       TempBuf[3] != 'H' || TempBuf[4] != 'E' || TempBuf[5] != 'S' )
   {
         return -1;
   }

   fseek( fp, 4, SEEK_CUR );            // Bytezahl �berspringen


   // Poly/Vertex/Texturdaten aller Submodels lesen
   fread( &TempShort, 2, 1, fp );
   PrepareNewP3DMeshData( TempShort );                      // Neue P3D mit bestimmter Meshanzahl vorbereiten
   P3DNumMeshes = TempShort;

   for( int m = 0; m < P3DNumMeshes; m++ )
   {

       // "SUBMESH"-Zeichen-Test
       fread( &TempBuf[0], 1, 7, fp );  
       if( TempBuf[0] != 'S' || TempBuf[1] != 'U' || TempBuf[2] != 'B' ||
           TempBuf[3] != 'M' || TempBuf[4] != 'E' || TempBuf[5] != 'S' ||
           TempBuf[6] != 'H' )
       {
          return -1;
       }
    
       fseek( fp, 4, SEEK_CUR );            // Bytezahl �berspringen
    

       // Meshname
       bzero( &TempBuf[0], 255 );
       for( int a = 0; ; a++ )
       {
           TempBuf[a] = fgetc( fp );
           if( TempBuf[a] == 0 ){ break; }
       }

       P3DMesh[m].Name = &TempBuf[0];


       // Meshdaten    
       fread( &P3DMesh[m].Flags, sizeof(MESHFLAGS), 1, fp );
       fread( &P3DMesh[m].LocalPos, 12, 1, fp );
       fread( &P3DMesh[m].Length, 4, 1, fp );
       fread( &P3DMesh[m].Height, 4, 1, fp );
       fread( &P3DMesh[m].Depth, 4, 1, fp );


       // Lies Texturierungsdaten
       for( i = 0; i < P3DNumTextures; i++ )  
       {
           fread( &P3DMesh[m].TextureInfo[i].TextureStart, 2, 1, fp );            // Start der Textur
           fread( &P3DMesh[m].TextureInfo[i].NumFlat, 2, 1, fp );                 // Anzahl der P3DPolymaterialen
           fread( &P3DMesh[m].TextureInfo[i].NumFlatMetal, 2, 1, fp );            // bei dieser Textur
           fread( &P3DMesh[m].TextureInfo[i].NumGouraud, 2, 1, fp );    
           fread( &P3DMesh[m].TextureInfo[i].NumGouraudMetal, 2, 1, fp );    
           fread( &P3DMesh[m].TextureInfo[i].NumGouraudMetalEnv, 2, 1, fp );    
           fread( &P3DMesh[m].TextureInfo[i].NumShining, 2, 1, fp );    
       }


       // Lies Vertexdaten   
       fread( &TempShort, 2, 1, fp );
      _ASSERT( TempShort > 0 );

       PrepareMeshVertices( m, TempShort );
       P3DMesh[m].NumVertices = TempShort;
   
       for( i = 0; i < P3DMesh[m].NumVertices; i++ )  
       {
            fread( &P3DMesh[m].Vertex[i].X, 4, 1, fp );  // Vertexkoordinaten
            fread( &P3DMesh[m].Vertex[i].Y, 4, 1, fp );  
            fread( &P3DMesh[m].Vertex[i].Z, 4, 1, fp );
       }
    
    
       // Lies Polygondaten
       fread( &TempShort, 2, 1, fp );
      _ASSERT( TempShort > 0 );

       PrepareMeshPolys( m, TempShort );
       P3DMesh[m].NumPolys = TempShort;

  
       for( i = 0; i < P3DMesh[m].NumPolys; i++ )  
       {
           fread( &P3DMesh[m].Poly[i].P1, 2, 1, fp );   // Vertexindex und Texcoords lesen
           fread( &P3DMesh[m].Poly[i].U1, 4, 1, fp );   // Punkt 1
           fread( &P3DMesh[m].Poly[i].V1, 4, 1, fp );   
    
           fread( &P3DMesh[m].Poly[i].P2, 2, 1, fp );   // Punkt 2
           fread( &P3DMesh[m].Poly[i].U2, 4, 1, fp );   
           fread( &P3DMesh[m].Poly[i].V2, 4, 1, fp );   
    
           fread( &P3DMesh[m].Poly[i].P3, 2, 1, fp );   // Punkt 3
           fread( &P3DMesh[m].Poly[i].U3, 4, 1, fp );   
           fread( &P3DMesh[m].Poly[i].V3, 4, 1, fp );
    
          _ASSERT( P3DMesh[m].Poly[i].P1 >= 0 && P3DMesh[m].Poly[i].P1 < P3DMesh[m].NumVertices );   // DebugTest
          _ASSERT( P3DMesh[m].Poly[i].P2 >= 0 && P3DMesh[m].Poly[i].P2 < P3DMesh[m].NumVertices );
          _ASSERT( P3DMesh[m].Poly[i].P3 >= 0 && P3DMesh[m].Poly[i].P3 < P3DMesh[m].NumVertices );
       }


       POLYGONCOUNT PolyInTex = 0;
    
    
       // Berechne die Texturen, die auf jedes P3DPolygon kommen
       for( i = 0; i < P3DNumTextures; i++ )
       {
            PolyInTex = P3DMesh[m].TextureInfo[i].TextureStart;  // Erstes P3DPolygon der Folge
    
            // Markiere alle Flatpolys
            for( int j = 0; j < P3DMesh[m].TextureInfo[i].NumFlat; j++ ){ P3DMesh[m].Poly[PolyInTex+j].Material = MAT_FLAT;
                                                                           P3DMesh[m].Poly[PolyInTex+j].Texture = P3DRenderInfo[i].TextureFile; }
            PolyInTex += P3DMesh[m].TextureInfo[i].NumFlat;
    
    
            // Markiere alle Flatmetalpolys
            for( j = 0; j < P3DMesh[m].TextureInfo[i].NumFlatMetal; j++ ){ P3DMesh[m].Poly[PolyInTex+j].Material = MAT_FLAT_METAL;
                                                                         P3DMesh[m].Poly[PolyInTex+j].Texture = P3DRenderInfo[i].TextureFile; }
            PolyInTex += P3DMesh[m].TextureInfo[i].NumFlatMetal;
    
    
            // Markiere alle Gouraudpolys
            for( j = 0; j < P3DMesh[m].TextureInfo[i].NumGouraud; j++ ){ P3DMesh[m].Poly[PolyInTex+j].Material = MAT_GOURAUD;
                                                                         P3DMesh[m].Poly[PolyInTex+j].Texture = P3DRenderInfo[i].TextureFile; }
            PolyInTex += P3DMesh[m].TextureInfo[i].NumGouraud;
    
    
            // Markiere alle Gouraudmetalpolys
            for( j = 0; j < P3DMesh[m].TextureInfo[i].NumGouraudMetal; j++ ){ P3DMesh[m].Poly[PolyInTex+j].Material = MAT_GOURAUD_METAL;
                                                                               P3DMesh[m].Poly[PolyInTex+j].Texture = P3DRenderInfo[i].TextureFile; }
            PolyInTex += P3DMesh[m].TextureInfo[i].NumGouraudMetal;
    
    
            // Markiere alle Gouraudmetalenvpolys
            for( j = 0; j < P3DMesh[m].TextureInfo[i].NumGouraudMetalEnv; j++ ){ P3DMesh[m].Poly[PolyInTex+j].Material = MAT_GOURAUD_METAL_ENV;
                                                                                 P3DMesh[m].Poly[PolyInTex+j].Texture = P3DRenderInfo[i].TextureFile; }
            PolyInTex += P3DMesh[m].TextureInfo[i].NumGouraudMetalEnv;
    
    
            // Markiere alle Shiningpolys
            for( j = 0; j < P3DMesh[m].TextureInfo[i].NumShining; j++ ){ P3DMesh[m].Poly[PolyInTex+j].Material = MAT_SHINING;
                                                                         P3DMesh[m].Poly[PolyInTex+j].Texture = P3DRenderInfo[i].TextureFile; }
       }
   }


   // "USER"-Zeichen-Test
   fread( &TempBuf[0], 1, 4, fp );  
   if( TempBuf[0] != 'U' || TempBuf[1] != 'S' || TempBuf[2] != 'E' ||
       TempBuf[3] != 'R' )
   {
         return -1;
   }

   fseek( fp, 4, SEEK_CUR );            // Bytezahl �berspringen


   // Lies Userdaten
   fread( &P3DUserDataSize, 4, 1, fp );

   if( P3DUserDataSize != 0 )
   {
      P3DUserDataPtr = new char[P3DUserDataSize];
      fread( P3DUserDataPtr, P3DUserDataSize, 1, fp );
   }
   else
   {
       P3DUserDataPtr = NULL;
   }



   fclose( fp );                      // Datei schlie�en
   return 0;
}



// LoadP3DFileV1 ( l�dt eine Modelldatei der P3D-Version 1 in die P3D-Struktur )
// =============================================================================

int LoadP3DFileV1( FILE* fp )
{

   PrepareNewP3DMeshData( 1 );         // In alter Version haben wir immer nur das Mainmesh
   P3DNumMeshes = 1;                   

   P3DMesh[0].Flags = MESHFLAG_MAIN | MESHFLAG_VISIBLE | MESHFLAG_TRACINGSHAPE;   
   P3DMesh[0].Name = "main";
   P3DMesh[0].LocalPos.X = 0;
   P3DMesh[0].LocalPos.Y = 0;
   P3DMesh[0].LocalPos.Z = 0;


   // �berspringe veraltete Daten
   char  TempBuf[32];
   short TempShort;
   
   fread( &TempBuf[0], 12, 1, fp );     // CrashEdit-Origin lesen
   fread( &TempBuf[0], 2, 1, fp );      // Zoomfaktoren lesen
   fread( &TempBuf[0], 2, 1, fp );      
   fread( &TempBuf[0], 2, 1, fp );      

   fread( &P3DLength, 4, 1, fp );       // Lies Objektma�e (und auf erstes Objekt �bertragen)
   fread( &P3DHeight, 4, 1, fp );
   fread( &P3DDepth, 4, 1, fp );
   P3DMesh[0].Length = P3DLength;
   P3DMesh[0].Height = P3DHeight;
   P3DMesh[0].Depth = P3DDepth;

   fread( &TempBuf[0], 1, 1, fp );      // �berspringe weiteres CrashEdit-Infobyte


   // Lies die P3DRenderInformationen
   fread( &P3DNumTextures, 1, 1, fp );
  _ASSERT( P3DNumTextures > 0 );


   for( int i = 0; i < P3DNumTextures; i++ )  
   {
        fread( &P3DMesh[0].TextureInfo[i].TextureStart, 2, 1, fp );    // Start der Textur
        fread( &TempBuf[0], 1, 18, fp );                               // 18 Byte des Texturnamens

        P3DRenderInfo[i].TextureFile  = &TempBuf[0];                
        P3DRenderInfo[i].TextureFile += ".tga";                
        P3DRenderInfo[i].TextureFile.lower();

        fread( &P3DMesh[0].TextureInfo[i].NumFlat, 2, 1, fp );         // Anzahl der P3DPolymaterialen
        fread( &P3DMesh[0].TextureInfo[i].NumFlatMetal, 2, 1, fp );    // bei dieser Textur
        fread( &P3DMesh[0].TextureInfo[i].NumGouraud, 2, 1, fp );    
        fread( &P3DMesh[0].TextureInfo[i].NumGouraudMetal, 2, 1, fp );    
        fread( &P3DMesh[0].TextureInfo[i].NumGouraudMetalEnv, 2, 1, fp );    
        fread( &P3DMesh[0].TextureInfo[i].NumShining, 2, 1, fp );    
   }


   // Lies Vertexdaten   
   fread( &TempShort, 2, 1, fp );                   // Vertexanzahl
  _ASSERT( TempShort > 0 );

   PrepareMeshVertices( 0, TempShort );
   P3DMesh[0].NumVertices = TempShort;

   for( i = 0; i < P3DMesh[0].NumVertices; i++ )  
   {
        fread( &P3DMesh[0].Vertex[i].X, 4, 1, fp );  // Vertexkoordinaten
        fread( &P3DMesh[0].Vertex[i].Y, 4, 1, fp );  
        fread( &P3DMesh[0].Vertex[i].Z, 4, 1, fp );

        P3DMesh[0].Vertex[i].X -= P3DLength/2;
        P3DMesh[0].Vertex[i].Y -= P3DHeight/2;
        P3DMesh[0].Vertex[i].Z += P3DDepth/2;
   }



   // Lies P3DPolygondaten
   fread( &TempShort, 2, 1, fp );                   // Polyanzahl
  _ASSERT( TempShort > 0 );

   PrepareMeshPolys( 0, TempShort );
   P3DMesh[0].NumPolys = TempShort;

   for( i = 0; i < P3DMesh[0].NumPolys; i++ )  
   {
       fread( &P3DMesh[0].Poly[i].P1, 2, 1, fp );   // Vertexindex und Texcoords lesen
       fread( &P3DMesh[0].Poly[i].U1, 4, 1, fp );   // Punkt 1
       fread( &P3DMesh[0].Poly[i].V1, 4, 1, fp );   

       fread( &P3DMesh[0].Poly[i].P2, 2, 1, fp );   // Punkt 2
       fread( &P3DMesh[0].Poly[i].U2, 4, 1, fp );   
       fread( &P3DMesh[0].Poly[i].V2, 4, 1, fp );   

       fread( &P3DMesh[0].Poly[i].P3, 2, 1, fp );   // Punkt 3
       fread( &P3DMesh[0].Poly[i].U3, 4, 1, fp );   
       fread( &P3DMesh[0].Poly[i].V3, 4, 1, fp );

      _ASSERT( P3DMesh[0].Poly[i].P1 >= 0 && P3DMesh[0].Poly[i].P1 < P3DMesh[0].NumVertices );   // DebugTest
      _ASSERT( P3DMesh[0].Poly[i].P2 >= 0 && P3DMesh[0].Poly[i].P2 < P3DMesh[0].NumVertices );
      _ASSERT( P3DMesh[0].Poly[i].P3 >= 0 && P3DMesh[0].Poly[i].P3 < P3DMesh[0].NumVertices );
   }

   POLYGONCOUNT PolyInTex = 0;


   // Berechne die Texturen, die auf jedes P3DPolygon kommen
   for( i = 0; i < P3DNumTextures; i++ )
   {
        PolyInTex = P3DMesh[0].TextureInfo[i].TextureStart;  // Erstes P3DPolygon der Folge

        // Markiere alle Flatpolys
        for( int j = 0; j < P3DMesh[0].TextureInfo[i].NumFlat; j++ ){ P3DMesh[0].Poly[PolyInTex+j].Material = MAT_FLAT;
                                                                       P3DMesh[0].Poly[PolyInTex+j].Texture = P3DRenderInfo[i].TextureFile; }
        PolyInTex += P3DMesh[0].TextureInfo[i].NumFlat;


        // Markiere alle Flatmetalpolys
        for( j = 0; j < P3DMesh[0].TextureInfo[i].NumFlatMetal; j++ ){ P3DMesh[0].Poly[PolyInTex+j].Material = MAT_FLAT_METAL;
                                                                     P3DMesh[0].Poly[PolyInTex+j].Texture = P3DRenderInfo[i].TextureFile; }
        PolyInTex += P3DMesh[0].TextureInfo[i].NumFlatMetal;


        // Markiere alle Gouraudpolys
        for( j = 0; j < P3DMesh[0].TextureInfo[i].NumGouraud; j++ ){ P3DMesh[0].Poly[PolyInTex+j].Material = MAT_GOURAUD;
                                                                     P3DMesh[0].Poly[PolyInTex+j].Texture = P3DRenderInfo[i].TextureFile; }
        PolyInTex += P3DMesh[0].TextureInfo[i].NumGouraud;


        // Markiere alle Gouraudmetalpolys
        for( j = 0; j < P3DMesh[0].TextureInfo[i].NumGouraudMetal; j++ ){ P3DMesh[0].Poly[PolyInTex+j].Material = MAT_GOURAUD_METAL;
                                                                           P3DMesh[0].Poly[PolyInTex+j].Texture = P3DRenderInfo[i].TextureFile; }
        PolyInTex += P3DMesh[0].TextureInfo[i].NumGouraudMetal;


        // Markiere alle Gouraudmetalenvpolys
        for( j = 0; j < P3DMesh[0].TextureInfo[i].NumGouraudMetalEnv; j++ ){ P3DMesh[0].Poly[PolyInTex+j].Material = MAT_GOURAUD_METAL_ENV;
                                                                             P3DMesh[0].Poly[PolyInTex+j].Texture = P3DRenderInfo[i].TextureFile; }
        PolyInTex += P3DMesh[0].TextureInfo[i].NumGouraudMetalEnv;


        // Markiere alle Shiningpolys
        for( j = 0; j < P3DMesh[0].TextureInfo[i].NumShining; j++ ){ P3DMesh[0].Poly[PolyInTex+j].Material = MAT_SHINING;
                                                                     P3DMesh[0].Poly[PolyInTex+j].Texture = P3DRenderInfo[i].TextureFile; }
   }



   // Lies Lichtdaten
   fread( &P3DNumLights, 2, 1, fp );

   for( i = 0; i < P3DNumLights; i++ )  
   {
       fread( &P3DLight[i].Pos.X, 4, 1, fp );              // Lichtposition
       fread( &P3DLight[i].Pos.Y, 4, 1, fp );   
       fread( &P3DLight[i].Pos.Z, 4, 1, fp );   

       P3DLight[i].Pos.X -= P3DLength/2;
       P3DLight[i].Pos.Y -= P3DHeight/2;
       P3DLight[i].Pos.Z += P3DDepth/2;

       fread( &P3DLight[i].Range, 4, 1, fp );              // Radius
       fread( &P3DLight[i].Color, 4, 1, fp );              // Farbe

       fread( &P3DLight[i].ShowCorona, 1, 1, fp );         // Zeige Coronas?
       fread( &P3DLight[i].ShowLensFlares, 1, 1, fp );     // Zeige LensFlares?
       fread( &P3DLight[i].LightUpEnvironment, 1, 1, fp ); // Strahle Licht aus?

       // Kreiere "Ersatz-Lichtnamen"
       sprintf( &TempBuf[0], "light%d", i );
       P3DLight[i].Name = &TempBuf[0];
   }


   fclose( fp );                      // Datei schlie�en

   return 0;
}




// SaveP3DFile ( speichert das aktuelle Objekt in einer Modelldatei )
// ==================================================================

void  SaveP3DFile( String filename )
{

  _ASSERT( P3DNumMeshes > 0 );

   // Fehler abfangen
   for( int m = 0; m < P3DNumMeshes; m++ )
   {
      _ASSERT( P3DMesh[m].NumVertices > 0 );
      _ASSERT( P3DMesh[m].NumPolys > 0 );

       if( P3DMesh[m].NumVertices >= P3DMANAG_MAXVERTICES )
       {
          _ERROR( "\nMeshes in P3D files cannot have more than 32767 vertices!" );
       }
    
       if( P3DMesh[m].NumPolys >= P3DMANAG_MAXPOLYS )
       {
          _ERROR( "\nMeshes in P3D files cannot have more than 32767 polys!" );
       }
   }
    
   if( P3DNumLights >= P3DMANAG_MAXLIGHTS )
   {
      _ERROR( "\nP3D files cannot have more than 255 polys!" );
   }



   // Datei �ffnen
  _fmode = O_BINARY;
   FILE* fp = fopen( filename, "w" ); 

   if( fp == NULL )
   {
       cout << "Can't create output file '" <<  filename << "' for writing!\n";
       cout << "Error code: " << errno << "\n";
       delay(5000);
       exit(0);
   }
   

   char  TempChar;      // Tempor�re Variablen
   char  TempBuf[256];
   int   TempInt;
   char  P3D[3] = { 'P', '3', 'D' };
   char  StringTextures[3] = { 'T', 'E', 'X' };
   char  StringLights[6] = { 'L', 'I', 'G', 'H', 'T', 'S' };
   char  StringMeshes[6] = { 'M', 'E', 'S', 'H', 'E', 'S' };
   char  StringSubMesh[7] = { 'S', 'U', 'B', 'M', 'E', 'S', 'H' };
   char  StringUser[4] = { 'U', 'S', 'E', 'R' };
   int   ByteCounter;
   int   SubMeshByteCounter;
   int   LastFSeekPos;
   int   LastMeshFSeekPos;


   // "P3D"-Zeichen setzen
   fwrite( &P3D[0], 1, 3, fp );  

   // Version setzen ( nur V.2 unterst�tzt )
   TempChar = P3D_FILEVERSION;
   fwrite( &TempChar, 1, 1, fp );


   fwrite( &P3DLength, 4, 1, fp );       // Schreibe Objektma�e
   fwrite( &P3DHeight, 4, 1, fp );
   fwrite( &P3DDepth, 4, 1, fp );


   // Es kann sein dass irgendwie ung�ltige Polys entstanden sind (P1=P2 oder �hnlich)
   // Nimm diese raus
   for( m = 0; m < P3DNumMeshes; m++ )             // In allen Meshes
   {
       for( int i = 0; i < P3DMesh[m].NumPolys; i++ )  
       {
           if( (P3DMesh[m].Poly[i].P1 == P3DMesh[m].Poly[i].P2 ||
               P3DMesh[m].Poly[i].P1 == P3DMesh[m].Poly[i].P3 ||
               P3DMesh[m].Poly[i].P2 == P3DMesh[m].Poly[i].P3) && P3DMesh[m].NumPolys > 1 )  // Falls Mesh mit 1 Linienpoly ("Bug" von Jan!)
           {
               for( int j = i; j < P3DMesh[m].NumPolys-1; j++ )
               {
                   P3DMesh[m].Poly[j].P1 = P3DMesh[m].Poly[j+1].P1;
                   P3DMesh[m].Poly[j].U1 = P3DMesh[m].Poly[j+1].U1;
                   P3DMesh[m].Poly[j].V1 = P3DMesh[m].Poly[j+1].V1;
                   P3DMesh[m].Poly[j].P2 = P3DMesh[m].Poly[j+1].P2;
                   P3DMesh[m].Poly[j].U2 = P3DMesh[m].Poly[j+1].U2;
                   P3DMesh[m].Poly[j].V2 = P3DMesh[m].Poly[j+1].V2;
                   P3DMesh[m].Poly[j].P3 = P3DMesh[m].Poly[j+1].P3;
                   P3DMesh[m].Poly[j].U3 = P3DMesh[m].Poly[j+1].U3;
                   P3DMesh[m].Poly[j].V3 = P3DMesh[m].Poly[j+1].V3;
                   P3DMesh[m].Poly[j].Texture = P3DMesh[m].Poly[j+1].Texture;
                   P3DMesh[m].Poly[j].Material = P3DMesh[m].Poly[j+1].Material;
               }
    
               P3DMesh[m].NumPolys--;
           }
       }
   }
    

   // Ab hier wird's hart
   // Finde alle Texturen und die zugeh�rigen P3DPolys und Materialien
   P3DTEXID Index;
   P3DNumTextures = 0;

   // Finde alle Texturen
   for( m = 0; m < P3DNumMeshes; m++ )             // In allen Meshes
   {
       for( int i = 0; i < P3DMesh[m].NumPolys; i++ )  
       {
           P3DMesh[m].Poly[i].Texture = P3DMesh[m].Poly[i].Texture.lower();

           // Finde aktuelle Textur und hole Texturindex
           if( IsTextureInList( P3DMesh[m].Poly[i].Texture ) == 0 )
           {
               Index = AddTextureToList( P3DMesh[m].Poly[i].Texture );
           }
           else
           {
               Index = GetTextureID( P3DMesh[m].Poly[i].Texture );
           }
    
           if( P3DMesh[m].Poly[i].Material == MAT_FLAT ){ P3DMesh[m].TextureInfo[Index].NumFlat++; }
           if( P3DMesh[m].Poly[i].Material == MAT_FLAT_METAL ){ P3DMesh[m].TextureInfo[Index].NumFlatMetal++; }
           if( P3DMesh[m].Poly[i].Material == MAT_GOURAUD ){ P3DMesh[m].TextureInfo[Index].NumGouraud++; }
           if( P3DMesh[m].Poly[i].Material == MAT_GOURAUD_METAL ){ P3DMesh[m].TextureInfo[Index].NumGouraudMetal++; }
           if( P3DMesh[m].Poly[i].Material == MAT_GOURAUD_METAL_ENV ){ P3DMesh[m].TextureInfo[Index].NumGouraudMetalEnv++; }
           if( P3DMesh[m].Poly[i].Material == MAT_SHINING ){ P3DMesh[m].TextureInfo[Index].NumShining++; }
       }
   }
    
    
   POLYGONCOUNT TotalPolyIndex;                    // Das aktuelle P3DPolygon im Durchlauf

   POLYGONCOUNT FindFlat, FindFlatMetal,           // Soviele P3DPolys sind in der Textur
                FindGouraud, FindGouraudMetal,     // zu suchen
                FindGouraudMetalEnv, FindShining;


   for( m = 0; m < P3DNumMeshes; m++ )             // In allen Meshes
   {

       TotalPolyIndex = 0;
       
       for( int i = 0; i < P3DNumTextures; i++ )  
       {


           // Finde Texturstartindex in P3DPolygonen
           if( i == 0 ){ P3DMesh[m].TextureInfo[0].TextureStart = 0; }
           else
           if( i > 0 ){ P3DMesh[m].TextureInfo[i].TextureStart = P3DMesh[m].TextureInfo[i-1].TextureStart + P3DMesh[m].TextureInfo[i-1].NumFlat + P3DMesh[m].TextureInfo[i-1].NumFlatMetal +
                                                                 P3DMesh[m].TextureInfo[i-1].NumGouraud + P3DMesh[m].TextureInfo[i-1].NumGouraudMetal + P3DMesh[m].TextureInfo[i-1].NumGouraudMetalEnv +
                                                                 P3DMesh[m].TextureInfo[i-1].NumShining; }
    
           // Setze die zu suchende P3DPolygonanzahl
           FindFlat = P3DMesh[m].TextureInfo[i].NumFlat;
           FindFlatMetal = P3DMesh[m].TextureInfo[i].NumFlatMetal;
           FindGouraud = P3DMesh[m].TextureInfo[i].NumGouraud;
           FindGouraudMetal = P3DMesh[m].TextureInfo[i].NumGouraudMetal;
           FindGouraudMetalEnv = P3DMesh[m].TextureInfo[i].NumGouraudMetalEnv;
           FindShining = P3DMesh[m].TextureInfo[i].NumShining;
    
    
           // Suche alle FlatPolys
           for( int j = 0; j < P3DMesh[m].NumPolys; j++ )
           {
                   if( P3DMesh[m].Poly[j].Texture == P3DRenderInfo[i].TextureFile &&
                       P3DMesh[m].Poly[j].Material == MAT_FLAT )
                   {
                       TotalPolyIndex++;                           // Ein P3DPoly mehr eingef�gt
                       FindFlat--;
                       PutToSavePoly( m, j, (TotalPolyIndex-1) );  // P3DPoly �bertragen
                   }
           }
          _ASSERT( FindFlat == 0 );
    
    
           // Suche alle FlatMetalPolys
           for( j = 0; j < P3DMesh[m].NumPolys; j++ )
           {
                   if( P3DMesh[m].Poly[j].Texture == P3DRenderInfo[i].TextureFile &&
                       P3DMesh[m].Poly[j].Material == MAT_FLAT_METAL )
                   {
                       TotalPolyIndex++;                           // Ein P3DPoly mehr eingef�gt
                       FindFlatMetal--;
                       PutToSavePoly( m, j, (TotalPolyIndex-1) );  // P3DPoly �bertragen
                   }
           }
          _ASSERT( FindFlatMetal == 0 );
    
    
           // Suche alle GouraudPolys
           for( j = 0; j < P3DMesh[m].NumPolys; j++ )
           {
                   if( P3DMesh[m].Poly[j].Texture == P3DRenderInfo[i].TextureFile &&
                       P3DMesh[m].Poly[j].Material == MAT_GOURAUD )
                   {
                       TotalPolyIndex++;                           // Ein P3DPoly mehr eingef�gt
                       FindGouraud--;
                       PutToSavePoly( m, j, (TotalPolyIndex-1) );  // P3DPoly �bertragen
                   }
           }
          _ASSERT( FindGouraud == 0 );
    
    
           // Suche alle GouraudMetalPolys
           for( j = 0; j < P3DMesh[m].NumPolys; j++ )
           {
                   if( P3DMesh[m].Poly[j].Texture == P3DRenderInfo[i].TextureFile &&
                       P3DMesh[m].Poly[j].Material == MAT_GOURAUD_METAL )
                   {
                       TotalPolyIndex++;                           // Ein P3DPoly mehr eingef�gt
                       FindGouraudMetal--;
                       PutToSavePoly( m, j, (TotalPolyIndex-1) );  // P3DPoly �bertragen
                   }
           }
          _ASSERT( FindGouraudMetal == 0 );
    
    
           // Suche alle GouraudMetalEnvPolys
           for( j = 0; j < P3DMesh[m].NumPolys; j++ )
           {
                   if( P3DMesh[m].Poly[j].Texture == P3DRenderInfo[i].TextureFile &&
                       P3DMesh[m].Poly[j].Material == MAT_GOURAUD_METAL_ENV )
                   {
                       TotalPolyIndex++;                           // Ein P3DPoly mehr eingef�gt
                       FindGouraudMetalEnv--;
                       PutToSavePoly( m, j, (TotalPolyIndex-1) );  // P3DPoly �bertragen
                   }
           }
          _ASSERT( FindGouraudMetalEnv == 0 );
    
    
           // Suche alle ShiningPolys
           for( j = 0; j < P3DMesh[m].NumPolys; j++ )
           {
                   if( P3DMesh[m].Poly[j].Texture == P3DRenderInfo[i].TextureFile &&
                       P3DMesh[m].Poly[j].Material == MAT_SHINING )
                   {
                       TotalPolyIndex++;                           // Ein P3DPoly mehr eingef�gt
                       FindShining--;
                       PutToSavePoly( m, j, (TotalPolyIndex-1) );  // P3DPoly �bertragen
                   }
           }

          _ASSERT( FindShining == 0 );
       }  

      _ASSERT( TotalPolyIndex == P3DMesh[m].NumPolys );  // Alle P3DPolys m�ssen verarbeitet worden sein
   }


   // Texturbeginn
   fwrite( &StringTextures[0], 3, 1, fp );
   LastFSeekPos = ftell( fp );
   fwrite( &TempInt, 4, 1, fp );                                        // ChunkSize erstmal mit Tempwert beschreiben

   ByteCounter = 0;


   // Schreibe Texturinfos die in allen Submodels gleich sind
   fwrite( &P3DNumTextures, 1, 1, fp );
   ByteCounter += 1;

   for( int i = 0; i < P3DNumTextures; i++ )  
   {
       // Schreibe kompletten Texturnamen (+ '\0')
       bzero( &TempBuf[0], 255 );
       for( int j = 0; j < P3DRenderInfo[i].TextureFile.length(); j++ )  
       {
           TempBuf[j] = P3DRenderInfo[i].TextureFile[j];
       }

       fwrite( &TempBuf[0], 1, P3DRenderInfo[i].TextureFile.length()+1, fp );  // Bytes des Texturnamens
       ByteCounter += P3DRenderInfo[i].TextureFile.length()+1;
   }


   fseek( fp, LastFSeekPos, SEEK_SET );   // Chunksize im Nachhinein eintragen
   fwrite( &ByteCounter, 4, 1, fp );
   fseek( fp, ByteCounter, SEEK_CUR );



   // Lichtbeginn
   fwrite( &StringLights[0], 6, 1, fp );
   LastFSeekPos = ftell( fp );
   fwrite( &TempInt, 4, 1, fp );                                        // ChunkSize erstmal mit Tempwert beschreiben

   ByteCounter = 0;


   // Schreibe Lichtdaten
   fwrite( &P3DNumLights, 2, 1, fp );
   ByteCounter += 2;

   for( i = 0; i < P3DNumLights; i++ )  
   {
       // Lichtname
       bzero( &TempBuf[0], 255 );
       for( int j = 0; j < P3DLight[i].Name.length(); j++ )  
       {
           TempBuf[j] = P3DLight[i].Name[j];
       }

       fwrite( &TempBuf[0], 1, P3DLight[i].Name.length()+1, fp );   // Bytes des Lichtnamens

       fwrite( &P3DLight[i].Pos.X, 4, 1, fp );              // Lichtposition
       fwrite( &P3DLight[i].Pos.Y, 4, 1, fp );   
       fwrite( &P3DLight[i].Pos.Z, 4, 1, fp );   

       fwrite( &P3DLight[i].Range, 4, 1, fp );              // Radius
       fwrite( &P3DLight[i].Color, 4, 1, fp );              // Farbe

       fwrite( &P3DLight[i].ShowCorona, 1, 1, fp );         // Zeige Coronas?
       fwrite( &P3DLight[i].ShowLensFlares, 1, 1, fp );     // Zeige LensFlares?
       fwrite( &P3DLight[i].LightUpEnvironment, 1, 1, fp ); // Strahle Licht aus?

       ByteCounter += P3DLight[i].Name.length()+1;
       ByteCounter += 23;
   }



   fseek( fp, LastFSeekPos, SEEK_SET );   // Chunksize im Nachhinein eintragen
   fwrite( &ByteCounter, 4, 1, fp );
   fseek( fp, ByteCounter, SEEK_CUR );



   // Meshbeginn
   fwrite( &StringMeshes[0], 6, 1, fp );
   LastFSeekPos = ftell( fp );
   fwrite( &TempInt, 4, 1, fp );                                        // ChunkSize erstmal mit Tempwert beschreiben

   ByteCounter = 0;


   // Poly/Vertex/Texturdaten aller Submodels sichern
   fwrite( &P3DNumMeshes, 2, 1, fp );
   ByteCounter += 2;

   for( m = 0; m < P3DNumMeshes; m++ )
   {

       // Submeshbeginn
       fwrite( &StringSubMesh[0], 7, 1, fp );
       LastMeshFSeekPos = ftell( fp );
       fwrite( &TempInt, 4, 1, fp );                                   // Submesh-ChunkSize erstmal mit Tempwert beschreiben

       ByteCounter += 11;
       SubMeshByteCounter = 0;


       // Meshname
       bzero( &TempBuf[0], 255 );
       for( int j = 0; j < P3DMesh[m].Name.length(); j++ )  
       {
           TempBuf[j] = P3DMesh[m].Name[j];
       }

       fwrite( &TempBuf[0], 1, P3DMesh[m].Name.length()+1, fp );   // Bytes des Meshnamens

       // Meshdaten    
       fwrite( &P3DMesh[m].Flags, sizeof(MESHFLAGS), 1, fp );
       fwrite( &P3DMesh[m].LocalPos, 12, 1, fp );
       fwrite( &P3DMesh[m].Length, 4, 1, fp );
       fwrite( &P3DMesh[m].Height, 4, 1, fp );
       fwrite( &P3DMesh[m].Depth, 4, 1, fp );

       ByteCounter += P3DMesh[m].Name.length()+1;
       ByteCounter += 28;
       SubMeshByteCounter += P3DMesh[m].Name.length()+1;
       SubMeshByteCounter += 28;


       // Schreibe Texturdaten
       for( i = 0; i < P3DNumTextures; i++ )  
       {
           fwrite( &P3DMesh[m].TextureInfo[i].TextureStart, 2, 1, fp );
           fwrite( &P3DMesh[m].TextureInfo[i].NumFlat, 2, 1, fp );                 // Anzahl der P3DPolymaterialen
           fwrite( &P3DMesh[m].TextureInfo[i].NumFlatMetal, 2, 1, fp );            // bei dieser Textur
           fwrite( &P3DMesh[m].TextureInfo[i].NumGouraud, 2, 1, fp );    
           fwrite( &P3DMesh[m].TextureInfo[i].NumGouraudMetal, 2, 1, fp );    
           fwrite( &P3DMesh[m].TextureInfo[i].NumGouraudMetalEnv, 2, 1, fp );    
           fwrite( &P3DMesh[m].TextureInfo[i].NumShining, 2, 1, fp );    

           ByteCounter += 14;
           SubMeshByteCounter += 14;
       }


       // Schreibe Vertexdaten   
       fwrite( &P3DMesh[m].NumVertices, 2, 1, fp );
       ByteCounter += 2;
       SubMeshByteCounter += 2;
    
       for( i = 0; i < P3DMesh[m].NumVertices; i++ )  
       {
            fwrite( &P3DMesh[m].Vertex[i].X, 4, 1, fp );  // Vertexkoordinaten
            fwrite( &P3DMesh[m].Vertex[i].Y, 4, 1, fp );  
            fwrite( &P3DMesh[m].Vertex[i].Z, 4, 1, fp );
            ByteCounter += 12;
            SubMeshByteCounter += 12;
       }
    
    
       // Schreibe P3DPolygondaten
       fwrite( &P3DMesh[m].NumPolys, 2, 1, fp );
       ByteCounter += 2;
       SubMeshByteCounter += 2;
    
       for( i = 0; i < P3DMesh[m].NumPolys; i++ )  
       {
            fwrite( &P3DMesh[m].SavePoly[i].P1, 2, 1, fp );  // P1
            fwrite( &P3DMesh[m].SavePoly[i].U1, 4, 1, fp );  
            fwrite( &P3DMesh[m].SavePoly[i].V1, 4, 1, fp );  
    
            fwrite( &P3DMesh[m].SavePoly[i].P2, 2, 1, fp );  // P2
            fwrite( &P3DMesh[m].SavePoly[i].U2, 4, 1, fp );  
            fwrite( &P3DMesh[m].SavePoly[i].V2, 4, 1, fp );  
    
            fwrite( &P3DMesh[m].SavePoly[i].P3, 2, 1, fp );  // P3
            fwrite( &P3DMesh[m].SavePoly[i].U3, 4, 1, fp );  
            fwrite( &P3DMesh[m].SavePoly[i].V3, 4, 1, fp );  

            ByteCounter += 30;
            SubMeshByteCounter += 30;
       }


       fseek( fp, LastMeshFSeekPos, SEEK_SET );
       fwrite( &SubMeshByteCounter, 4, 1, fp );
       fseek( fp, SubMeshByteCounter, SEEK_CUR );
   }
    

   fseek( fp, LastFSeekPos, SEEK_SET );       // Chunksize im Nachhinein eintragen
   fwrite( &ByteCounter, 4, 1, fp );
   fseek( fp, ByteCounter, SEEK_CUR );



   // Meshbeginn
   fwrite( &StringUser[0], 4, 1, fp );
   LastFSeekPos = ftell( fp );
   fwrite( &TempInt, 4, 1, fp );                                        // ChunkSize erstmal mit Tempwert beschreiben

   ByteCounter = 0;


   // Schreib Userdaten
   fwrite( &P3DUserDataSize, 4, 1, fp );

   if( P3DUserDataPtr != NULL )
   {
      fwrite( P3DUserDataPtr, P3DUserDataSize, 1, fp );
   }

   ByteCounter = 4 + P3DUserDataSize;


   fseek( fp, LastFSeekPos, SEEK_SET );   // Chunksize im Nachhinein eintragen
   fwrite( &ByteCounter, 4, 1, fp );


   fclose( fp );                          // Datei schlie�en
}

