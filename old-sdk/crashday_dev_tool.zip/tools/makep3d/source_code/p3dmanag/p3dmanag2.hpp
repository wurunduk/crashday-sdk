// ==================================================================
//
//   p3dmanag2.hpp - Schnittstelle zu P3D-Managementfunktionen,
//                   die das Laden/Speichern von P3D-Files erlauben
//                   P3D-Version 2
//
//   Autor:    Robert Clemens
//   Start:    28.10.00
//
// ==================================================================

#ifndef _P3DMANAG2_HPP_INCLUDED_

#define _P3DMANAG2_HPP_INCLUDED_



//
//   P3D-Structure
//   
//   - Header
//   - Texture list
//   - Lights list
//   - Mesh list
//      - Texture data
//      - Vertex lists
//      - Poly lists
//


#include <string.hpp>

#define  P3D_FILEVERSION                2         // Version 2 dieses Formats

#define  MESHFLAG_MAIN                  1         // Das Mesh ist das Haupt-Mesh (muss immer erstes Obj in P3D sein)
#define  MESHFLAG_VISIBLE               2         // Ist das Objekt jemals sichtbar
#define  MESHFLAG_TRACINGSHAPE          4         // Objekt ist Tracing-Silhouette
#define  MESHFLAG_COLLISIONSHAPE        8         // Objekt ist Kollisionsobjekt
#define  MESHFLAG_DETACHABLE_PART      16         // Objekt ist abfallendes Teil bei einem Auto
#define  MESHFLAG_BREAKABLE_GLASS      32         // Objekt ist zerbrechliches Glass
#define  MESHFLAG_BREAKABLE_PLASTIC    64         // Objekt ist zerbrechliche Plastik
#define  MESHFLAG_BREAKABLE_WOOD      128         // Objekt ist zerbrechliches Holzteil
#define  MESHFLAG_BREAKABLE_METAL     256         // Objekt ist zerbrechliches Metallteil
#define  MESHFLAG_NUMBERPLATE         512         // Objekt ist ein Nummernschild
#define  MESHFLAG_HEADLIGHT          1024         // Objekt ist ein Scheinwerfer
#define  MESHFLAG_BRAKELIGHT         2048         // Objekt ist ein Bremslicht


#define  P3DMANAG_MAXMESHES             32
#define  P3DMANAG_MAXTEXTURES           256
#define  P3DMANAG_MAXVERTICES           32768
#define  P3DMANAG_MAXPOLYS              32768
#define  P3DMANAG_MAXLIGHTS             256


// Debugging-Makros

// ASSERT - Makro
#ifndef _ASSERT
#define _ASSERT(x)   \
                        if (!(x)) \
                        { \
                              cout << "Error!\nAnnahme '" << #x << "' nicht zutreffend!\n"; \
                              cout << "Datei " << __FILE__ << ",\nZeile " << __LINE__ <<"\n"; \
                              exit( -1 ); \
                        }
#endif

// Mit Message beenden
#ifndef _ERROR
#define _ERROR(x)   \
                       cout << "Error!\n" << (x) << "\n"; \
                       cout << "Datei " << __FILE__ << ",\nZeile " << __LINE__ <<"\n"; \
                       exit( -1 );
#endif


// Mit Message und Wertausgabe beenden
#ifndef _ERROR_M
#define _ERROR_M(x, y) \
                       cout << "Error!\n"; \
                       cout << "Datei " << __FILE__ << ", Zeile " << __LINE__ <<"\n\n"; \
                       cout << (x) << "\n"; \
                       cout << #y << ": " << (y) << "\n"; \
                       exit( -1 ); 
#endif


typedef unsigned int    MESHFLAGS;       // Bestimmte Flags f�r Submeshes
typedef signed short    MESHCOUNT;       // Anzahl an Submeshes
typedef signed short    VERTEXCOUNT;     // Vertexanzahl
typedef signed short    POLYGONCOUNT;    // Polygonanzahl
typedef signed short    LIGHTCOUNT;      // Lichteranzahl
typedef float            P3DVALUE;        // Floatwert
typedef int              P3DCOLOR;        // Farbwert RGB
typedef unsigned char   P3DTEXID;        // TexturID



// Polygon-Renderarten
enum P3DMATERIAL {  MAT_FLAT              = 0,    // Flach ohne Verlauf
                     MAT_FLAT_METAL        = 1,    // Flach mit Metaleffekt
                     MAT_GOURAUD           = 2,    // Weicher Verlauf
                     MAT_GOURAUD_METAL     = 3,    // Weicher Verlauf mit Metalleffekt
                     MAT_GOURAUD_METAL_ENV = 4,    // Weicher Verlauf, Metal & Environmentmap
                     MAT_SHINING           = 5 };  // Leuchtend




// Informationen zum Rendering der einzelnen Texturen
struct RENDERINFO
{
    String       TextureFile;          // Name der Texturdatei
};


// Informationen zur Verwendung einer Textur in einem Mesh
struct TEXTUREINFO
{
    POLYGONCOUNT TextureStart;         // Index des Polys des Submeshes das zuerst diese Textur verwendet

    POLYGONCOUNT NumFlat;              // Polys dieser Textur mit Flatshading
    POLYGONCOUNT NumFlatMetal;         // Polys dieser Textur mit Metalshading
    POLYGONCOUNT NumGouraud;           // Polys dieser Textur mit Gouraudshading
    POLYGONCOUNT NumGouraudMetal;      // Polys dieser Textur mit Gouraudmetalshading
    POLYGONCOUNT NumGouraudMetalEnv;   // Polys dieser Textur mit Gouraudmetalshading & EnvMap
    POLYGONCOUNT NumShining;           // Polys dieser Textur, die leuchten
};



// Vertex des Objects
struct P3DVERTEX
{
    P3DVALUE X,  Y,  Z;    // Koordinaten 
};



// Informationen zu einem Licht
struct P3DLIGHT
{
    String     Name;           // Meshname
    P3DVERTEX  Pos;            // Lichtposition
    P3DVALUE   Range;          // Lichtradius
    P3DCOLOR   Color;          // Lichtfarbindex

    char      ShowCorona;     // Zeige Corona
    char      ShowLensFlares; // Zeige LensFlares

    char      LightUpEnvironment;  // Umgebung beleuchten?
};



// Exakte Informationen �ber ein Poly des P3DModels
struct P3DTEXPOLYGON
{
    String         Texture;        // Name der Texturdatei
    P3DMATERIAL    Material;       // Material des Polys

    VERTEXCOUNT    P1;             // Index der Polygonvertexe
    VERTEXCOUNT    P2;             // (in Verwendung mit einem
    VERTEXCOUNT    P3;             //  Vertexzeiger)

    P3DVALUE       U1, V1;         // Texturkoordinaten der Vertexe
    P3DVALUE       U2, V2;         
    P3DVALUE       U3, V3;         
};



// Struktur in der die Polys am Ende gesichert werden
struct SAVEPOLYGON
{
    VERTEXCOUNT    P1;             // Index der Polygonvertexe
    VERTEXCOUNT    P2;             // (in Verwendung mit einem
    VERTEXCOUNT    P3;             //  Vertexzeiger)

    P3DVALUE       U1, V1;         // Texturkoordinaten der Vertexe
    P3DVALUE       U2, V2;         
    P3DVALUE       U3, V3;         
};



// Informationen �ber ein Mesh in der P3D
struct P3DMESH
{
    String        Name;                               // Meshname
    MESHFLAGS     Flags;                              // Flags eines Mesh-Objektes
    VERTEXCOUNT   NumVertices;                        // Anzahl von Vertexen
    VERTEXCOUNT   NumVerticesAllocated;               // Anzahl von allokierten Vertexen
    POLYGONCOUNT  NumPolys;                           // Polygonen
    POLYGONCOUNT  NumPolysAllocated;                  // Anzahl an allokierten Polygonen

    TEXTUREINFO   TextureInfo[P3DMANAG_MAXTEXTURES];  // Verwendung der Texturen in diesem Submesh

    P3DVERTEX*    Vertex;                             // Rohe 3D-Vertexdaten
    P3DTEXPOLYGON*Poly;                               // Polygondaten

    P3DVERTEX     LocalPos;                           // Mittelpunkt lokal zum Mittelpunkt des anderen Objektes
    P3DVALUE      Length;                             // Breite
    P3DVALUE      Height;                             // H�he
    P3DVALUE      Depth;                              // Tiefe
    

    // Internal
    SAVEPOLYGON*  SavePoly;                           // Zu speichernde Polygondaten
};



// Externe Variablen, die vorm Speichern gef�llt werden m�ssen

extern MESHCOUNT     P3DNumMeshes;                              // Submeshes im Objekt
extern MESHCOUNT     P3DNumMeshesAllocated;                     // Anzahl allokierter Meshes
extern P3DMESH*      P3DMesh;                                   // Meshdaten

extern LIGHTCOUNT    P3DNumLights;                              // Lichtern im Objekt
extern P3DLIGHT      P3DLight[P3DMANAG_MAXLIGHTS];              // Lichterdaten

extern  P3DVALUE     P3DLength;                                 // Objektma�e (entspricht dem Mainobjekt)
extern  P3DVALUE     P3DDepth;
extern  P3DVALUE     P3DHeight;

extern  int          P3DUserDataSize;                             // Zus�tzliche Userdaten
extern  char*        P3DUserDataPtr;

// Internal
extern P3DTEXID      P3DNumTextures;                           // Anzahl an verschiedenen Texturen
extern RENDERINFO    P3DRenderInfo[P3DMANAG_MAXTEXTURES];      // Daten von Texturen und Materialien



// Lade/Speichern-Funktionen
int  LoadP3DFile( String filename );        // L�dt Modell aus Datei der Version 2
void SaveP3DFile( String filename );        // Speichert das Modell in Version 2

// Auch intern genutzte Funktionen, um m�gliche Buffer zu allokieren
void PrepareNewP3DMeshData( MESHCOUNT );             // Neue P3D vorbereiten in dem eine bestimmte Anzahl an Meshes allokiert wird
void PrepareMeshVertices( MESHCOUNT, VERTEXCOUNT );  // Vertices eines Meshes vorbereiten
void PrepareMeshPolys( MESHCOUNT, POLYGONCOUNT );    // Polys eines Meshes vorbereiten



#endif    // p3dmanag2.hpp
