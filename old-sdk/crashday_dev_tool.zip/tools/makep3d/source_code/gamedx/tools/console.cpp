/// ==================================================================
///
///   console.cpp - Vereinfacht das Arbeiten mit dem Konsolenfenster (conout etc)
///
///   Autor:    Robert Clemens
///   Start:    25.10.04
///
/// ==================================================================

#include "console.hpp"
#include <windows.h>
#include <stdlib.h>


/// Setze die Konsolen-Ausgabefarbe
/// ===============================

void SetConsoleColor( CONCOLOR col )
{
    HANDLE StandardCOUTHandle = GetStdHandle( STD_OUTPUT_HANDLE );
    
    if( col == CONCOL_RED )
    {
        SetConsoleTextAttribute( StandardCOUTHandle, FOREGROUND_RED | FOREGROUND_INTENSITY );
    }
    else
    if( col == CONCOL_GREEN )
    {
        SetConsoleTextAttribute( StandardCOUTHandle, FOREGROUND_GREEN | FOREGROUND_INTENSITY );
    }
    else
    if( col == CONCOL_BLUE )
    {
        SetConsoleTextAttribute( StandardCOUTHandle, FOREGROUND_BLUE | FOREGROUND_INTENSITY );
    }
    else
    if( col == CONCOL_YELLOW )
    {
        SetConsoleTextAttribute( StandardCOUTHandle, FOREGROUND_GREEN | FOREGROUND_RED | FOREGROUND_INTENSITY );
    }
    else
    if( col == CONCOL_CYAN )
    {
        SetConsoleTextAttribute( StandardCOUTHandle, FOREGROUND_GREEN | FOREGROUND_BLUE | FOREGROUND_INTENSITY );
    }
    else
    if( col == CONCOL_MAGENTA )
    {
        SetConsoleTextAttribute( StandardCOUTHandle, FOREGROUND_BLUE | FOREGROUND_RED | FOREGROUND_INTENSITY );
    }
    else
    if( col == CONCOL_WHITE )
    {
        SetConsoleTextAttribute( StandardCOUTHandle, FOREGROUND_GREEN | FOREGROUND_RED | FOREGROUND_BLUE | FOREGROUND_INTENSITY );
    }
    else
    {
        SetConsoleTextAttribute( StandardCOUTHandle, FOREGROUND_GREEN | FOREGROUND_RED | FOREGROUND_BLUE );
    }
}



/// L�sche den Bildschirm
/// =====================
void ClearConsoleScreen()
{
    system( "cls" );
}

