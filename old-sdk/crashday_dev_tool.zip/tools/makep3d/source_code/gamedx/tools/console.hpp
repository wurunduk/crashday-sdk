/// ==================================================================
///
///   console.hpp - Vereinfacht das Arbeiten mit dem Konsolenfenster (conout etc)
///
///   Autor:    Robert Clemens
///   Start:    25.10.04
///
/// ==================================================================

#ifndef _CONSOLE_HPP_INCLUDED_

#define _CONSOLE_HPP_INCLUDED_


enum CONCOLOR
{
    CONCOL_WHITE        = 0,
    CONCOL_RED          = 1,
    CONCOL_GREEN        = 2,
    CONCOL_BLUE         = 3,
    CONCOL_YELLOW       = 4,
    CONCOL_CYAN         = 5,
    CONCOL_MAGENTA      = 6,
    CONCOL_DEFAULT      = 7
};


/// Setze die Konsolenfarbe
/// =======================
void SetConsoleColor( CONCOLOR col );


/// L�sche den Bildschirm
/// =====================
void ClearConsoleScreen();


#endif       /// console.hpp
