// 3ds to p3d converter (p3d version 2)


#include <conio.h>
#include <iostream.h>
#include <fstream.h>
#include <fcntl.h>
#include <dos.h>
#include <io.h>
#include <i86.h>
#include <direct.h>

#include "../clh/log.hpp"
#include "../clh/path.hpp"
#include "../clh/filename.hpp"

#include "../p3dmanag/p3dmanag2.hpp"
#include "../../gamedx/tools/console.hpp"

#include "lib3ds/file.h"
#include "lib3ds/vector.h"
#include "lib3ds/matrix.h"
#include "lib3ds/camera.h"
#include "lib3ds/light.h"
#include "lib3ds/material.h"
#include "lib3ds/mesh.h"
#include "lib3ds/node.h"
#include "stdlib.h"
#include "string.h"
#include "math.h"


struct ConvertOptions
{
    char  Overwrite;
    char  From3DSMax;
    char  IgnoreDuplicateVertices;
    char  UseSmoothingGroups;
    char  SwapPolyOrder;
    char  MirrorX;
    char  MirrorY;
    char  MirrorZ;
    char  NoTextures;
    float Scaling;
    float LowerBoundTop;
    float LowerBoundBottom;
    char  ShowLensFlares;
    char  SlowOut;
    char  ShaderTest;
};

struct SmoothingGroups
{
    short NumVerts;                                             // Anzahl an Verts f�r diese SG
    short SGVerts[ P3DMANAG_MAXVERTICES ];                      // Die Indices auf die einzelnen Verts
};


ConvertOptions  Options;                                         // Convert-Optionen
char            TexturesConverted[P3DMANAG_MAXTEXTURES]; 
String          input = "";                                      // Einlese-3Ds
String          output = "";                                     // Schreib zu P3D

short          MaxSmoothingGroups = 257;
short          SmoothingGroupsUsed = 0;
SmoothingGroups SG[ 257 ];                                       // List of smoothing groups
short          SGFrom3DSGroup[ 257 ];                           // Liste der urspr�nglichen SG-Indices, die jetzt geordnet
                                                                 // in der P3D liegen




// ����������������������������������������������������������������������������
void parse_args(int argc, char **argv)
// ����������������������������������������������������������������������������
{

    Options.Overwrite = 0;                              // Parameter resetten
    Options.From3DSMax = 0;
    Options.IgnoreDuplicateVertices = 0;
    Options.UseSmoothingGroups = 0;
    Options.SwapPolyOrder = 0;
    Options.MirrorX = 0;
    Options.MirrorY = 0;
    Options.MirrorZ = 0;
    Options.NoTextures = 0;
    Options.Scaling = 1.0;
    Options.LowerBoundTop = 0.0;
    Options.LowerBoundBottom = 0.0;
    Options.ShowLensFlares = 0;
    Options.SlowOut = 0;
    Options.ShaderTest = 0;

    cout << "\n\nPassed options: ";
    SetConsoleColor( CONCOL_YELLOW );


    for( int i = 1; i < argc; i++ )             // Durchlaufe alle Args
    {
        if( strcmp( argv[i], "-in" ) == 0 )
        {
            i++;
            input = argv[i];
        }
        else
        if( strcmp( argv[i], "-out" ) == 0 )
        {
            i++;
            output = argv[i];
        }
        else
        if( strcmp( argv[i], "-ignoredupl" ) == 0 )
        {
            Options.IgnoreDuplicateVertices = 1;
            cout << "ignoreduplicate, ";
        }
        else
        if( strcmp( argv[i], "-sgs" ) == 0 )
        {
            Options.UseSmoothingGroups = 1;
            cout << "smoothinggroups, ";
        }
        else
        if( strcmp( argv[i], "-swap" ) == 0 )
        {
            Options.SwapPolyOrder = 1;
            cout << "swappolyorder, ";
        }
        else
        if( strcmp( argv[i], "-owrite" ) == 0 )
        {
            Options.Overwrite = 1;
            cout << "overwrite, ";
        }
        else
        if( strcmp( argv[i], "-readable" ) == 0 )
        {
            Options.SlowOut = 1;
            cout << "readable, ";
        }
        else
        if( strcmp( argv[i], "-max" ) == 0 )
        {
            Options.From3DSMax = 1;
            Options.SwapPolyOrder = 1 - Options.SwapPolyOrder;  // Polyorder umdrehen
            cout << "max, ";
        }
        else
        if( strcmp( argv[i], "-mirrorx" ) == 0 )
        {
            Options.MirrorX = 1;
            cout << "mirrorx, ";
        }
        else
        if( strcmp( argv[i], "-mirrory" ) == 0 )
        {
            Options.MirrorY = 1;
            cout << "mirrory, ";
        }
        else
        if( strcmp( argv[i], "-mirrorz" ) == 0 )
        {
            Options.MirrorZ = 1;
            cout << "mirrorz, ";
        }
        else
        if( strcmp( argv[i], "-scale" ) == 0 )
        {
            i++;
            Options.Scaling = atof( argv[i] );
            cout << "scaling = " << argv[i] << ", ";
        }
        else
        if( strcmp( argv[i], "-lowertopbound" ) == 0 )
        {
            i++;
            Options.LowerBoundTop = atof( argv[i] );
            cout << "lowertopbound = " << argv[i] << ", ";
        }
        else
        if( strcmp( argv[i], "-liftbottombound" ) == 0 )
        {
            i++;
            Options.LowerBoundBottom = atof( argv[i] );
            cout << "liftbottombound = " << argv[i] << ", ";
        }
        else
        if( strcmp( argv[i], "-notex" ) == 0 )
        {
            Options.NoTextures = 1;
            cout << "notex, ";
        }
        else
        if( strcmp( argv[i], "-flares" ) == 0 )
        {
            Options.ShowLensFlares = 1;
            cout << "flares, ";
        }
        else
        if( strcmp( argv[i], "-shadertest" ) == 0 )
        {
            Options.ShaderTest = 1;
            cout << "shadertest, ";
        }
    }


    if( input == "" || output == "" )
    {
        cout << "\nFile arguments are missing!\n\n";
        if( input == "" )
        {
           cout << "\n-> input-3DS model : ";
           SetConsoleColor( CONCOL_CYAN );
           cin  >> input;
           SetConsoleColor( CONCOL_YELLOW );
        }

        if( output == "" )
        {
           cout << "\n-> output-P3D model : ";
           SetConsoleColor( CONCOL_CYAN );
           cin  >> output;
           SetConsoleColor( CONCOL_YELLOW );
        }
    }

    cout << "\n\n";
}


// ����������������������������������������������������������������������������
short Convert3DSGroupToP3DGroup( short sg )
// ����������������������������������������������������������������������������
{
    // Suche f�r die SG von 3DStudio einen Platz in den SGs der P3D
    for( int i = 0; i < SmoothingGroupsUsed; i++ )
    {
        if( SGFrom3DSGroup[i] == sg ){ return i; }
    }


    if( SmoothingGroupsUsed == MaxSmoothingGroups )        // Keine Groups mehr da
    {
        cout << "Limit of 256 diff. smoothing groups exceeded! Model might contain erros\n";

        return 0;  // Nimm Smoothinggroup 0
    }

    // Erzeuge einen neuen Eintrag f�r eine weitere SG
    SGFrom3DSGroup[SmoothingGroupsUsed] = sg;
    SmoothingGroupsUsed++;

    //cout << "\nUsing new smoothing group. 3DS group '" << sg << "' becomes P3D group '" << (SmoothingGroupsUsed-1) << "'";

    return (SmoothingGroupsUsed-1);
}



int save_to_p3d();

// ����������������������������������������������������������������������������
void convert_to_p3d( Lib3dsFile *f, String file )
// ����������������������������������������������������������������������������
{

      SetConsoleColor( CONCOL_GREEN );
      cout << "\nMaster scale: " << f->master_scale << "\n\n";
      SetConsoleColor( CONCOL_DEFAULT );
      

      if( Options.SlowOut ){ delay(1000); }   // We want to read the texts


      Lib3dsLight* lightptr = f->lights;                                          // Alle Lichter durchgehen
      P3DNumLights = 0;
      char        ColR, ColG, ColB;

      for( lightptr = f->lights; lightptr != NULL; lightptr = lightptr->next )  
      {

          P3DLight[P3DNumLights].Name = (char const*) lightptr->name;

          if( !Options.From3DSMax )
          {
             P3DLight[P3DNumLights].Pos.X = lightptr->position[0];
             P3DLight[P3DNumLights].Pos.Y = lightptr->position[2];
             P3DLight[P3DNumLights].Pos.Z = lightptr->position[1];
          }
          else
          {
             P3DLight[P3DNumLights].Pos.X = lightptr->position[0];
             P3DLight[P3DNumLights].Pos.Y = lightptr->position[1];
             P3DLight[P3DNumLights].Pos.Z = lightptr->position[2];
          }

           P3DLight[P3DNumLights].Pos.X *= f->master_scale;
           P3DLight[P3DNumLights].Pos.Y *= f->master_scale;
           P3DLight[P3DNumLights].Pos.Z *= f->master_scale;
           

           if( Options.SlowOut ){ delay(1000); }   // We want to read the texts


           P3DLight[P3DNumLights].Range = (lightptr->inner_range + lightptr->outer_range) / 2;
           P3DLight[P3DNumLights].ShowCorona = 0;
           P3DLight[P3DNumLights].ShowLensFlares = Options.ShowLensFlares;
           P3DLight[P3DNumLights].LightUpEnvironment = 1;

//           cout << "Light info '" << P3DLight[P3DNumLights].Name << "': radius=" << P3DLight[P3DNumLights].Range << " ";
//           cout << "posxyz=" << P3DLight[P3DNumLights].Pos.X << "," << P3DLight[P3DNumLights].Pos.Y << "," << P3DLight[P3DNumLights].Pos.Z << "\n";

           if( lightptr->color[0] < 0 ){ lightptr->color[0] = 0; }
           if( lightptr->color[0] > 1 ){ lightptr->color[0] = 1; }
           if( lightptr->color[1] < 0 ){ lightptr->color[1] = 0; }
           if( lightptr->color[1] > 1 ){ lightptr->color[1] = 1; }
           if( lightptr->color[2] < 0 ){ lightptr->color[2] = 0; }
           if( lightptr->color[2] > 1 ){ lightptr->color[2] = 1; }

           ColR = (unsigned char) (255.0f* lightptr->color[0]);
           ColG = (unsigned char) (255.0f* lightptr->color[1]);
           ColB = (unsigned char) (255.0f* lightptr->color[2]);

           P3DLight[P3DNumLights].Color = (ColR << 16) + (ColG << 8) + ColB;

          
           P3DNumLights++;
           if( P3DNumLights == P3DMANAG_MAXLIGHTS ){ break; }     // Liste ist voll

     }

     cout << P3DNumLights << " lights read...\n";

     if( Options.SlowOut ){ delay(1000); }   // We want to read the texts


     // Durchlaufe alles Meshes
     P3DVERTEX    ObjCenter;
     
     Lib3dsMesh*  throughallmodels = f->meshes;
     Lib3dsMesh** meshindexlist;
     Lib3dsMesh*  m;
     int i = 0;
     int mesh = 0;
     int mainobjectindex = -1;
     int tracingobjectindex = -1;
     int collobjectindex = -1;
     String Temp;

     String* MeshNames = new String[ 128 ];   // Wir wollen vorher alle Meshnamen haben um doppelte Meshes zu l�schen


     // Meshes z�hlen
     short TempMeshCount = 0;
     for( throughallmodels = f->meshes; throughallmodels != NULL; throughallmodels = throughallmodels->next )
     {
         // Teste ob Mesh evtl. schon vorher vorhanden war
         MeshNames[ TempMeshCount ] = throughallmodels->name;

         for( int m = 0; m < TempMeshCount; m++ )
         {
             if( MeshNames[m] == MeshNames[TempMeshCount] ){ break; }  // Selbes Mesh nochmal gefunden!
         }

         if( m == TempMeshCount ){ TempMeshCount++; }  // Modell zuf�gen, da vorher noch nicht vorhanden
     }


     // Meshes im Speicher allokieren
     PrepareNewP3DMeshData( TempMeshCount );
     P3DNumMeshes = TempMeshCount;
     



     // Meshliste erstellen
     meshindexlist = new Lib3dsMesh*[ P3DNumMeshes ];      
     for( i = 0, throughallmodels = f->meshes; i < P3DNumMeshes; throughallmodels = throughallmodels->next, i++ )
     {
         if( throughallmodels->name != MeshNames[i] ){ i--; continue; }   // Evtl. wurde hier ein Mesh ausgelassen weils doppelt war
         meshindexlist[i] = throughallmodels;
     }


     delete [] MeshNames;
     MeshNames = NULL;
     

     for( int counter = 0; counter < P3DNumMeshes; counter++ )
     {

         if( mainobjectindex == -1 )    // Das Main-Modell der 3DS soll an die erste Stelle der P3D
         {
             // Finde Mainobject
             Lib3dsMesh* tempmesh = f->meshes;
             int         tempid = 0;
             for( tempid = 0; tempid < P3DNumMeshes; tempid++ )
             {
                 Temp = (char const*) meshindexlist[tempid]->name;
                 if( Temp == "main" )            // Hier liegt das Mainobjekt, beginne damit
                 {
                     mainobjectindex = tempid;
                     break;
                 }
             }

             if( mainobjectindex == -1 )        // Kein Obj namens "Main" gefunden, nimm einfach erstes Objekt
             {
                 mainobjectindex = 0;
             }

             mesh = mainobjectindex;


             // Finde Tracingobject
             tempmesh = f->meshes;
             for( tempid = 0; tempid < P3DNumMeshes; tempid++ )
             {
                 Temp = (char const*) meshindexlist[tempid]->name;
                 if( Temp == "mainshad" )      // Hier liegt das Tracingobjekt
                 {
                     tracingobjectindex = tempid;
                     break;
                 }
             }

             if( tracingobjectindex == -1 )        // Kein Obj namens "mainshad" gefunden, nimm einfach erstes Objekt
             {
                 tracingobjectindex = mainobjectindex;
             }


             // Finde Collisionobject
             tempmesh = f->meshes;
             for( tempid = 0; tempid < P3DNumMeshes; tempid++ )
             {
                 Temp = (char const*) meshindexlist[tempid]->name;
                 if( Temp == "maincoll" )      // Hier liegt das Tracingobjekt
                 {
                     collobjectindex = tempid;
                     break;
                 }
             }

             if( collobjectindex == -1 )        // Kein Obj namens "maincoll" gefunden, nimm einfach erstes Objekt
             {
                 collobjectindex = mainobjectindex;
             }
         }
         else
         {
             if( mesh == mainobjectindex )   // Letztes Objekt war das Mainobjekt
             {
                 if( mesh > 0 ){ mesh = 0; }
                 else { mesh = 1; }
             }
             else
             {
                 mesh++;
                 if( mesh == mainobjectindex )
                 {
                     mesh++;
                 }
             }
         }
         

         m = meshindexlist[mesh]; 
         
         P3DMesh[counter].Name = (char const*) m->name;

         // Zur Allokation der Vertexdaten m�ssen mehr Vertices als in der FIle allokiert werden,
         // da z.B. durch Smoothinggroups die Vertexanzahl noch ansteigen kann. Maximal k�nnen es 3x so viele
         // Vertices werden

         PrepareMeshVertices( counter, 3 * m->points );        // Max. 3fache Vertanzahl
         PrepareMeshPolys( counter, m->faces );

         P3DMesh[counter].NumVertices = m->points;
         P3DMesh[counter].NumPolys = m->faces;


         // Evtl. Spaces im Namen durch Unterstriche ersetzen
         for( int a = 0; a < P3DMesh[counter].Name.length(); a++ )
         {
             if( P3DMesh[counter].Name[a] == ' ' ){ P3DMesh[counter].Name[a] = '_'; }
         }


         // Flags analysieren        
         P3DMesh[counter].Flags = MESHFLAG_VISIBLE;
         if( mesh == mainobjectindex )
         {
            P3DMesh[counter].Name = "main";
            P3DMesh[counter].Flags |= MESHFLAG_MAIN;
         }
         if( mesh == tracingobjectindex )
         {
            P3DMesh[counter].Flags |= MESHFLAG_TRACINGSHAPE;
            if( mesh != mainobjectindex )
            {
               P3DMesh[counter].Flags |= MESHFLAG_VISIBLE;        // Visible entfernen
               P3DMesh[counter].Flags ^= MESHFLAG_VISIBLE;
            }
         }
         if( mesh == collobjectindex )
         {
            P3DMesh[counter].Flags |= MESHFLAG_COLLISIONSHAPE;
            if( mesh != mainobjectindex )
            {
               P3DMesh[counter].Flags |= MESHFLAG_VISIBLE;        // Visible entfernen
               P3DMesh[counter].Flags ^= MESHFLAG_VISIBLE;
            }
         }

    
         SetConsoleColor( CONCOL_DEFAULT );
         cout << "\nConverting submodel '";
         SetConsoleColor( CONCOL_YELLOW );
         cout << P3DMesh[counter].Name;
         SetConsoleColor( CONCOL_DEFAULT );
         cout << "' to P3D...\n";
         cout << m->points << " vertices, " << m->faces << " polygons...\n";
         cout << m->texels << " texels...\n";

         if( Options.SlowOut ){ delay(1000); }   // We want to read the texts


         float TempX, TempY, TempZ, TempW;
         for( int i = 0; i < P3DMesh[counter].NumVertices; i++ )  // Kopiere Vertexdaten
         {
             if( !Options.From3DSMax )
             {
                TempX = m->pointL[i].pos[0];   // Z/Y vertauschen
                TempY = m->pointL[i].pos[2];
                TempZ = m->pointL[i].pos[1];
             }
             else
             {
                TempX = m->pointL[i].pos[0];   // Z/Y nicht vertauschen
                TempY = m->pointL[i].pos[1];
                TempZ = m->pointL[i].pos[2];
             }

             float othermat[4][4];
             othermat[0][0] = m->matrix[0][0];
             othermat[0][1] = m->matrix[1][0];
             othermat[0][2] = m->matrix[2][0];
             othermat[0][3] = m->matrix[3][0];
             othermat[1][0] = m->matrix[0][1];
             othermat[1][1] = m->matrix[1][1];
             othermat[1][2] = m->matrix[2][1];
             othermat[1][3] = m->matrix[3][1];
             othermat[2][0] = m->matrix[0][2];
             othermat[2][1] = m->matrix[1][2];
             othermat[2][2] = m->matrix[2][2];
             othermat[2][3] = m->matrix[3][2];
             othermat[3][0] = m->matrix[0][3];
             othermat[3][1] = m->matrix[1][3];
             othermat[3][2] = m->matrix[2][3];
             othermat[3][3] = m->matrix[3][3];
    
    
             // Mesh-Matrix auf Verts anwenden
             TempW = TempX*othermat[3][0] + TempY*othermat[3][1] + TempZ*othermat[3][2] + othermat[3][3];
    
             if( TempW == 0 ){ continue; }
             TempW = 1 / TempW;
    
             P3DMesh[counter].Vertex[i].X = (TempX*othermat[0][0] + TempY*othermat[0][1] + TempZ*othermat[0][2] + othermat[0][3]) * TempW;
             P3DMesh[counter].Vertex[i].Y = (TempX*othermat[1][0] + TempY*othermat[1][1] + TempZ*othermat[1][2] + othermat[1][3]) * TempW;
             P3DMesh[counter].Vertex[i].Z = (TempX*othermat[2][0] + TempY*othermat[2][1] + TempZ*othermat[2][2] + othermat[2][3]) * TempW;

         }
  
       
         CDDir->GoToDirectory( "TEXTURES" );
    
      
         for( i = 0; i < P3DMesh[counter].NumPolys; i++ )          // Kopiere Polydaten
         {
    
             P3DMesh[counter].Poly[i].P1 = m->faceL[i].points[0];               
             P3DMesh[counter].Poly[i].P2 = m->faceL[i].points[2];
             P3DMesh[counter].Poly[i].P3 = m->faceL[i].points[1];

             if( m->faceL[i].points[0] < m->texels ){ P3DMesh[counter].Poly[i].U1 = m->texelL[m->faceL[i].points[0]][0]; }
             if( m->faceL[i].points[2] < m->texels ){ P3DMesh[counter].Poly[i].U2 = m->texelL[m->faceL[i].points[2]][0]; }
             if( m->faceL[i].points[1] < m->texels ){ P3DMesh[counter].Poly[i].U3 = m->texelL[m->faceL[i].points[1]][0]; }
             if( m->faceL[i].points[0] < m->texels ){ P3DMesh[counter].Poly[i].V1 = 1 - m->texelL[m->faceL[i].points[0]][1]; }
             if( m->faceL[i].points[2] < m->texels ){ P3DMesh[counter].Poly[i].V2 = 1 - m->texelL[m->faceL[i].points[2]][1]; }
             if( m->faceL[i].points[1] < m->texels ){ P3DMesh[counter].Poly[i].V3 = 1 - m->texelL[m->faceL[i].points[1]][1]; }

             P3DMesh[counter].Poly[i].Texture = "colwhite.tga";  // Vor�bergehende Settings (falls kein Mat. existiert)
             P3DMesh[counter].Poly[i].Material = MAT_GOURAUD;

    
             Lib3dsMaterial* material = f->materials;           // Suche Texturname des Materials auf diesem Poly
             int             mat_id = 0;
        
             for( material = f->materials; material != NULL; material = material->next, mat_id++ )  
             {
                     if( strcmp( material->name, m->faceL[i].material ) == 0 )  // Dieses Material verwendet das Poly
                     {
                         String P3DTexName = "";
                         if( Options.NoTextures || material->texture1_map.name[0] == '\0' ) // Keine Textur auf diesem Material
                         {
                             P3DTexName = "colwhite.tga";                               // Ersatztextur
                         }
                         else
                         {
                             for( int a = 0; material->texture1_map.name[a] != '.' && material->texture1_map.name[a] != '\0'; a++ )
                             {
                                 P3DTexName += material->texture1_map.name[a];
                             }
                             P3DTexName += ".tga";                                      // Erweiterung an Texturnamen h�ngen
                         }
        
                         // Textur �bernehmen
                         P3DMesh[counter].Poly[i].Texture = P3DTexName;
        
                         // Gib eine Meldung dar�ber aus, ob die Textur bereits als TGA existiert
                         if( TexturesConverted[mat_id] == 0 )   // 0 heisst Status wurde noch nicht berechnet
                         {
                             String NameWithFolder;
                             NameWithFolder = GetPathFromString( file ) + P3DTexName;
                             if( access( NameWithFolder, F_OK ) != 0 )
                             {
                                 cout << "! '" << NameWithFolder << "' still needs to be converted to TGA!\n\n";
                                 if( Options.SlowOut ){ delay(1000); }   // We want to read the texts
                             }
        
                             TexturesConverted[mat_id] = 1;
                         }
                         
        
        
                         // Material f�r P3D-Poly suchen
                         if( material->self_illum ||                                    // Selbstleuchtend
                             (material->ambient[0] == 1.0 &&
                              material->ambient[1] == 1.0 &&
                              material->ambient[2] == 1.0) )
                         {
                             P3DMesh[counter].Poly[i].Material = MAT_SHINING;
                         }
                         else                                                          // Keine Reflectionmap
                         if( material->reflection_map.name[0] != '\0' )                // Es existiert eine Reflection-Map
                         {
                             P3DMesh[counter].Poly[i].Material = MAT_GOURAUD_METAL_ENV;
                         }
                         else                                                          // Keine Reflectionmap
                         {
                             if( m->faceL[i].smoothing != 0 )
                             {
                                 P3DMesh[counter].Poly[i].Material = MAT_GOURAUD;
                             }
                             else                                     // Mache alles != SG ist FLAT
                             {
                                 P3DMesh[counter].Poly[i].Material = MAT_FLAT;
                             }
                         }
       
                     }
             }
             
       }


       // Die �berfl�ssigen Verts k�nnen jetzt noch aus der Vertexliste genommen werden
       int used;
       int erased = 0;
    
       if( !Options.IgnoreDuplicateVertices )
       {
    
           // Entferne "doppelte" Verts oder merge die die nahe beieinander liegen
           for( i = 0; i < P3DMesh[counter].NumVertices; i++ )
           {
               for( int j = i+1; j < P3DMesh[counter].NumVertices; j++ )  // Teste, ob andere Vertexe dem �u�eren Vert �hnlich sind
               {
                   if( fabs( P3DMesh[counter].Vertex[i].X - P3DMesh[counter].Vertex[j].X ) <= 0 &&  
                       fabs( P3DMesh[counter].Vertex[i].Y - P3DMesh[counter].Vertex[j].Y ) <= 0 &&
                       fabs( P3DMesh[counter].Vertex[i].Z - P3DMesh[counter].Vertex[j].Z ) <= 0 )     // Ersetze Vertex
                   {
                       for( int p = 0; p < P3DMesh[counter].NumPolys; p++ )              // Ersetze Indices bei den Polys
                       {
                           if( P3DMesh[counter].Poly[p].P1 == j ){ P3DMesh[counter].Poly[p].P1 = i; }
                           if( P3DMesh[counter].Poly[p].P2 == j ){ P3DMesh[counter].Poly[p].P2 = i; }
                           if( P3DMesh[counter].Poly[p].P3 == j ){ P3DMesh[counter].Poly[p].P3 = i; }
                       }
                   }
               }
           }
        
    
           for( i = 0; i < P3DMesh[counter].NumVertices; i++ )
           {
               used = 0;
               for( int p = 0; p < P3DMesh[counter].NumPolys; p++ )       // Z�hle ob Vertex �berhaupt noch irgendwo verwendet wird
               {
                   if( P3DMesh[counter].Poly[p].P1 == i ){ used = 1; break; }
                   if( P3DMesh[counter].Poly[p].P2 == i ){ used = 1; break; }
                   if( P3DMesh[counter].Poly[p].P3 == i ){ used = 1; break; }
               }
        
               if( !used )   // Vertex ist nicht mehr verwendet, nimm ihn aus der Liste und ziehe andere vor
               {
                  for( int j = i; j < P3DMesh[counter].NumVertices-1; j++ )
                  {
                      P3DMesh[counter].Vertex[j].X = P3DMesh[counter].Vertex[j+1].X;
                      P3DMesh[counter].Vertex[j].Y = P3DMesh[counter].Vertex[j+1].Y;
                      P3DMesh[counter].Vertex[j].Z = P3DMesh[counter].Vertex[j+1].Z;
                  }
        
                  for( int p = 0; p < P3DMesh[counter].NumPolys; p++ )        // �ndere alle Polys, deren Vertices vorgezogen sind
                  {
                      if( P3DMesh[counter].Poly[p].P1 > i ){ P3DMesh[counter].Poly[p].P1--; }
                      if( P3DMesh[counter].Poly[p].P2 > i ){ P3DMesh[counter].Poly[p].P2--; }
                      if( P3DMesh[counter].Poly[p].P3 > i ){ P3DMesh[counter].Poly[p].P3--; }
                  }
        
                  erased++;
                  P3DMesh[counter].NumVertices--;
                  i--;                   // Das n�chste i-Element haben wir vorgezogen, also mache den Step nochmal
               }
           }
    
           cout << "Erased " << erased << " duplicate vertices in '" << P3DMesh[counter].Name << "'. New v-count: " << P3DMesh[counter].NumVertices << "\n";
           if( Options.SlowOut ){ delay(1000); }   // We want to read the texts
       }
       else
       {
           cout << "Ignoring duplicated vertices (if any)...\n";
           if( Options.SlowOut ){ delay(1000); }   // We want to read the texts
       }

    
    
    
       // Polys an Smoothing-Groups "auseinander brechen"
       if( Options.UseSmoothingGroups )
       {
    
           cout << "Duplicating vertices on smoothing group edges...\n";
           cout << "Used smoothing groups: ";
    
           int vert1onsg;
           int vert2onsg;
           int vert3onsg;
           int V1AlreadyInOtherSG;
           int V2AlreadyInOtherSG;
           int V3AlreadyInOtherSG;
           int vertsadded = 0;

           SmoothingGroupsUsed = 0;
           for( int i = 0; i < MaxSmoothingGroups; i++ )     // SmoothingGroup-Verts resetten
           {
               SG[i].NumVerts = 0;
               SGFrom3DSGroup[i] = -1;
           }


           // Die Nummern der Smoothinggroups in der 3DS
           // werden in spezielle Nummern f�r die P3D gesichert (zusammenh�ngend)
           for( i = 0; i < P3DMesh[counter].NumPolys; i++ )
           {
               m->faceL[i].smoothing = Convert3DSGroupToP3DGroup( m->faceL[i].smoothing );
           }

    
           // Liste alle verwendeten SmoothingGroups auf
           for( i = 0; i < P3DMesh[counter].NumPolys; i++ )
           {

               vert1onsg = P3DMesh[counter].Poly[i].P1;   // Die 3 Vertices des Polys benutzen diese SmoothingGroup
               vert2onsg = P3DMesh[counter].Poly[i].P2;
               vert3onsg = P3DMesh[counter].Poly[i].P3;
               V1AlreadyInOtherSG = 0;
               V2AlreadyInOtherSG = 0;
               V3AlreadyInOtherSG = 0;
    
    
               // Nun lass uns gucken ob welche der 3 Verts vielleicht schon irgendeiner anderen
               // SG zugeordnet sind. Wenn das der Fall ist, erzeuge einen doppelten Vertex.
    
               for( int sg = 0; sg < SmoothingGroupsUsed; sg++ )
               {
                   if( sg == m->faceL[i].smoothing ){ continue; }     // Eigene SG nicht testen
                   
                   for( int j = 0; j < SG[sg].NumVerts; j ++ )
                   {
                       if( vert1onsg == SG[sg].SGVerts[j] ){ V1AlreadyInOtherSG = 1; } // Vertex existiert in andere SmoothGroup
                       if( vert2onsg == SG[sg].SGVerts[j] ){ V2AlreadyInOtherSG = 1; }
                       if( vert3onsg == SG[sg].SGVerts[j] ){ V3AlreadyInOtherSG = 1; }
                   }
               }
               
    
               if( V1AlreadyInOtherSG == 0 )                // Vert 1 noch nicht in anderer SG
               {
                   if( SG[ m->faceL[i].smoothing ].NumVerts == 0 )  // Als neu genutzte SG ausgeben
                   {
                       cout << m->faceL[i].smoothing << ",";
                   }
               }
               else                                          // Vert 1 existiert schon in anderer SG. Erzeuge neuen Vertex ab
               {
                   P3DMesh[counter].NumVertices++;
                   P3DMesh[counter].Vertex[P3DMesh[counter].NumVertices-1].X = P3DMesh[counter].Vertex[vert1onsg].X;  // Vert zuf�gen
                   P3DMesh[counter].Vertex[P3DMesh[counter].NumVertices-1].Y = P3DMesh[counter].Vertex[vert1onsg].Y;
                   P3DMesh[counter].Vertex[P3DMesh[counter].NumVertices-1].Z = P3DMesh[counter].Vertex[vert1onsg].Z;
    
                   P3DMesh[counter].Poly[i].P1 = P3DMesh[counter].NumVertices-1;
    
                   // Alle nachfolgenden Polys, die zur selben SG geh�ren und auch genau DIESEN vertex verwenden
                   // m�ssen den Index auch �ndern
                   for( int p = i; p < P3DMesh[counter].NumPolys; p++ )
                   {
                        if( m->faceL[p].smoothing != m->faceL[i].smoothing ){ continue; }
    
                        if( P3DMesh[counter].Poly[p].P1 == vert1onsg ){ P3DMesh[counter].Poly[p].P1 = P3DMesh[counter].NumVertices-1; }
                        if( P3DMesh[counter].Poly[p].P2 == vert1onsg ){ P3DMesh[counter].Poly[p].P2 = P3DMesh[counter].NumVertices-1; }
                        if( P3DMesh[counter].Poly[p].P3 == vert1onsg ){ P3DMesh[counter].Poly[p].P3 = P3DMesh[counter].NumVertices-1; }
                   }
    
    
                   vert1onsg = P3DMesh[counter].NumVertices-1;
                   vertsadded++;
               }
    
               SG[ m->faceL[i].smoothing ].SGVerts[ SG[ m->faceL[i].smoothing ].NumVerts ] = vert1onsg;
               SG[ m->faceL[i].smoothing ].NumVerts++;
    
    
    
               if( V2AlreadyInOtherSG == 0 )                // Vert 2 noch nicht in anderer SG
               {
                   if( SG[ m->faceL[i].smoothing ].NumVerts == 0 )  // Als neu genutzte SG ausgeben
                   {
                       cout << m->faceL[i].smoothing << ",";
                   }
               }
               else                                          // Vert 2 existiert schon in anderer SG. Erzeuge neuen Vertex ab
               {
                   P3DMesh[counter].NumVertices++;
                   P3DMesh[counter].Vertex[P3DMesh[counter].NumVertices-1].X = P3DMesh[counter].Vertex[vert2onsg].X;  // Vert zuf�gen
                   P3DMesh[counter].Vertex[P3DMesh[counter].NumVertices-1].Y = P3DMesh[counter].Vertex[vert2onsg].Y;
                   P3DMesh[counter].Vertex[P3DMesh[counter].NumVertices-1].Z = P3DMesh[counter].Vertex[vert2onsg].Z;
    
                   P3DMesh[counter].Poly[i].P2 = P3DMesh[counter].NumVertices-1;
    
                   // Alle nachfolgenden Polys, die zur selben SG geh�ren und auch genau DIESEN vertex verwenden
                   // m�ssen den Index auch �ndern
                   for( int p = i; p < P3DMesh[counter].NumPolys; p++ )
                   {
                        if( m->faceL[p].smoothing != m->faceL[i].smoothing ){ continue; }
    
                        if( P3DMesh[counter].Poly[p].P1 == vert2onsg ){ P3DMesh[counter].Poly[p].P1 = P3DMesh[counter].NumVertices-1; }
                        if( P3DMesh[counter].Poly[p].P2 == vert2onsg ){ P3DMesh[counter].Poly[p].P2 = P3DMesh[counter].NumVertices-1; }
                        if( P3DMesh[counter].Poly[p].P3 == vert2onsg ){ P3DMesh[counter].Poly[p].P3 = P3DMesh[counter].NumVertices-1; }
                   }
    
    
                   vert2onsg = P3DMesh[counter].NumVertices-1;
                   vertsadded++;
               }
    
               SG[ m->faceL[i].smoothing ].SGVerts[ SG[ m->faceL[i].smoothing ].NumVerts ] = vert2onsg;
               SG[ m->faceL[i].smoothing ].NumVerts++;
    
    
    
               if( V3AlreadyInOtherSG == 0 )                // Vert 3 noch nicht in anderer SG
               {
                   if( SG[ m->faceL[i].smoothing ].NumVerts == 0 )  // Als neu genutzte SG ausgeben
                   {
                       cout << m->faceL[i].smoothing << ",";
                   }
               }
               else                                          // Vert 3 existiert schon in anderer SG. Erzeuge neuen Vertex ab
               {
                   P3DMesh[counter].NumVertices++;
                   P3DMesh[counter].Vertex[P3DMesh[counter].NumVertices-1].X = P3DMesh[counter].Vertex[vert3onsg].X;  // Vert zuf�gen
                   P3DMesh[counter].Vertex[P3DMesh[counter].NumVertices-1].Y = P3DMesh[counter].Vertex[vert3onsg].Y;
                   P3DMesh[counter].Vertex[P3DMesh[counter].NumVertices-1].Z = P3DMesh[counter].Vertex[vert3onsg].Z;
    
                   P3DMesh[counter].Poly[i].P3 = P3DMesh[counter].NumVertices-1;
    
                   // Alle nachfolgenden Polys, die zur selben SG geh�ren und auch genau DIESEN vertex verwenden
                   // m�ssen den Index auch �ndern
                   for( int p = i; p < P3DMesh[counter].NumPolys; p++ )
                   {
                        if( m->faceL[p].smoothing != m->faceL[i].smoothing ){ continue; }
    
                        if( P3DMesh[counter].Poly[p].P1 == vert3onsg ){ P3DMesh[counter].Poly[p].P1 = P3DMesh[counter].NumVertices-1; }
                        if( P3DMesh[counter].Poly[p].P2 == vert3onsg ){ P3DMesh[counter].Poly[p].P2 = P3DMesh[counter].NumVertices-1; }
                        if( P3DMesh[counter].Poly[p].P3 == vert3onsg ){ P3DMesh[counter].Poly[p].P3 = P3DMesh[counter].NumVertices-1; }
                   }
    
    
                   vert3onsg = P3DMesh[counter].NumVertices-1;
                   vertsadded++;
               }
    
               SG[ m->faceL[i].smoothing ].SGVerts[ SG[ m->faceL[i].smoothing ].NumVerts ] = vert3onsg;
               SG[ m->faceL[i].smoothing ].NumVerts++;
    
           }
        
           cout << "\n";
           cout << "Added " << vertsadded << " vertices in '" << P3DMesh[counter].Name << "'. New v-count is " << P3DMesh[counter].NumVertices << "\n";
           if( Options.SlowOut ){ delay(1000); }   // We want to read the texts
       }
       

       // Gr��e der Meshes analyisieren
       float lowx, lowy, lowz;
       float highx, highy, highz;
       lowx = highx = P3DMesh[counter].Vertex[0].X;
       lowy = highy = P3DMesh[counter].Vertex[0].Y;
       lowz = highz = P3DMesh[counter].Vertex[0].Z;

       for( i = 1; i < P3DMesh[counter].NumVertices; i++ )  // Finde "kleinsten"/"gr��ten" Punkt
       {
           if( P3DMesh[counter].Vertex[i].X < lowx ){ lowx = P3DMesh[counter].Vertex[i].X; }
           if( P3DMesh[counter].Vertex[i].Y < lowy ){ lowy = P3DMesh[counter].Vertex[i].Y; }
           if( P3DMesh[counter].Vertex[i].Z < lowz ){ lowz = P3DMesh[counter].Vertex[i].Z; }
           if( P3DMesh[counter].Vertex[i].X > highx ){ highx = P3DMesh[counter].Vertex[i].X; }
           if( P3DMesh[counter].Vertex[i].Y > highy ){ highy = P3DMesh[counter].Vertex[i].Y; }
           if( P3DMesh[counter].Vertex[i].Z > highz ){ highz = P3DMesh[counter].Vertex[i].Z; }
       }

       P3DMesh[counter].Length = highx - lowx;   // Ma�e als Differenz der min/max-Punkte
       P3DMesh[counter].Depth = highz - lowz;
       P3DMesh[counter].Height = highy - lowy;
/*
       // "20er"-Alignment f�r Felder
       if( P3DMesh[counter].Length > 19.97 && P3DMesh[counter].Length < 20.03 )   // Hier gibts immer Rundungsprobleme
       { P3DMesh[counter].Length = 20.0f; }
       if( P3DMesh[counter].Length > 39.97 && P3DMesh[counter].Length < 40.03 )
       { P3DMesh[counter].Length = 40.0f; }
       if( P3DMesh[counter].Depth > 19.97 && P3DMesh[counter].Depth < 20.03 )
       { P3DMesh[counter].Depth = 20.0f; }
       if( P3DMesh[counter].Depth > 39.97 && P3DMesh[counter].Depth < 40.03 )
       { P3DMesh[counter].Depth = 40.0f; }
*/

       if( mesh == mainobjectindex )               // Mainobjekt ist Mittelpunkt alle anderen Objekte
       {
           // Zus�tzliche Spezial-BBoxes auch beachten, die nicht genau den
           // Ma�en der Vertexe entsprechen (Verts d�rfen oben/unten rausgucken)
           lowy += Options.LowerBoundBottom;
           highy -= Options.LowerBoundTop;

           P3DMesh[counter].Height = highy - lowy;      // H�he evtl. durch Lifting ge�ndert


           ObjCenter.X = (highx + lowx) / 2;
           ObjCenter.Y = (highy + lowy) / 2;
           ObjCenter.Z = (highz + lowz) / 2;

           P3DLength = P3DMesh[counter].Length;
           P3DHeight = P3DMesh[counter].Height;
           P3DDepth = P3DMesh[counter].Depth;

           SetConsoleColor( CONCOL_GREEN );
           cout << "\nMain dimensions:\n";
           cout << "Width: " << (double)P3DLength << ", Height: " << (double)P3DHeight << ", Depth: " << (double)P3DDepth << "\n";
           SetConsoleColor( CONCOL_DEFAULT );

           if( Options.SlowOut ){ delay(1000); }   // We want to read the texts


           if( P3DLength >= 19.95 && P3DLength <= 20.05 ){ P3DLength = 20; };
           if( P3DLength >= 39.95 && P3DLength <= 40.05 ){ P3DLength = 40; };
           if( P3DDepth >= 19.95 && P3DDepth <= 20.05 ){ P3DDepth = 20; };
           if( P3DDepth >= 39.95 && P3DDepth <= 40.05 ){ P3DDepth= 40; };

           
           P3DMesh[counter].LocalPos.X = 0;
           P3DMesh[counter].LocalPos.Y = 0;
           P3DMesh[counter].LocalPos.Z = 0;


           for( i = 0; i < P3DNumLights; i++ )   // Auch die Lichter lokal zum Mittelpunkt hinverschieben
           {
               P3DLight[i].Pos.X -= ObjCenter.X - meshindexlist[mainobjectindex]->matrix[3][0];
               P3DLight[i].Pos.Y -= ObjCenter.Y - meshindexlist[mainobjectindex]->matrix[3][1];
               P3DLight[i].Pos.Z -= ObjCenter.Z - meshindexlist[mainobjectindex]->matrix[3][2];
           }

       }
       else                     // Position lokal zum Mittelpunkt (im Main-Obj) ermitteln
       {
           P3DMesh[counter].LocalPos.X = (highx + lowx) / 2 - ObjCenter.X;
           P3DMesh[counter].LocalPos.Y = (highy + lowy) / 2 - ObjCenter.Y;
           P3DMesh[counter].LocalPos.Z = (highz + lowz) / 2 - ObjCenter.Z;
       }


       // Verschiebe alle Meshes so, dass sie jeweils zu ihrem Mittelpunkt relativ sind
       for( i = 0; i < P3DMesh[counter].NumVertices; i++ )
       {
           P3DMesh[counter].Vertex[i].X -= (highx + lowx) / 2;
           P3DMesh[counter].Vertex[i].Y -= (highy + lowy) / 2;
           P3DMesh[counter].Vertex[i].Z -= (highz + lowz) / 2;
       }


     }  // Ende Mesh-Durchlauf


     // Skalingoperation durchf�hren     
     if( Options.Scaling != 1.0f )             // Skalingoperation durchf�hren
     {
          for( int counter = 0; counter < P3DNumMeshes; counter++ )
          {
               P3DMesh[counter].Length *= Options.Scaling;
               P3DMesh[counter].Height *= Options.Scaling;
               P3DMesh[counter].Depth *= Options.Scaling;

/*
               // Nochmals "20er"-Alignment f�r Felder
               if( P3DMesh[counter].Length > 19.97 && P3DMesh[counter].Length < 20.03 )   // Hier gibts immer Rundungsprobleme
               { P3DMesh[counter].Length = 20.0f; }
               if( P3DMesh[counter].Length > 39.97 && P3DMesh[counter].Length < 40.03 )
               { P3DMesh[counter].Length = 40.0f; }
               if( P3DMesh[counter].Depth > 19.97 && P3DMesh[counter].Depth < 20.03 )
               { P3DMesh[counter].Depth = 20.0f; }
               if( P3DMesh[counter].Depth > 39.97 && P3DMesh[counter].Depth < 40.03 )
               { P3DMesh[counter].Depth = 40.0f; }
*/
    
               if( P3DMesh[counter].Flags & MESHFLAG_MAIN )
               {
                   P3DLength = P3DMesh[counter].Length;
                   P3DHeight = P3DMesh[counter].Height;
                   P3DDepth = P3DMesh[counter].Depth;
               }
        
               P3DMesh[counter].LocalPos.X *= Options.Scaling;
               P3DMesh[counter].LocalPos.Y *= Options.Scaling;
               P3DMesh[counter].LocalPos.Z *= Options.Scaling;


               // Meshvertices scalen
               for( i = 0; i < P3DMesh[counter].NumVertices; i++ )
               {
                  P3DMesh[counter].Vertex[i].X *= Options.Scaling;
                  P3DMesh[counter].Vertex[i].Y *= Options.Scaling;
                  P3DMesh[counter].Vertex[i].Z *= Options.Scaling;
               }
          }


          for( i = 0; i < P3DNumLights; i++ )   // Lichterpositionen scalen
          {
             P3DLight[i].Pos.X *= Options.Scaling;
             P3DLight[i].Pos.Y *= Options.Scaling;
             P3DLight[i].Pos.Z *= Options.Scaling;
          }
    }




   // Modell spiegeln
   if( Options.MirrorX )
   {
       for( int m = 0; m < P3DNumMeshes; m++ )
       {
          for( i = 0; i < P3DMesh[m].NumVertices; i++ ){ P3DMesh[m].Vertex[i].X = -1*(P3DMesh[m].Vertex[i].X + P3DMesh[m].LocalPos.X) - P3DMesh[m].LocalPos.X; }
       }
       for( i = 0; i < P3DNumLights; i++ ){   P3DLight[i].Pos.X = -P3DLight[i].Pos.X; }
   }
   if( Options.MirrorY )
   {
       for( int m = 0; m < P3DNumMeshes; m++ )
       {
          for( i = 0; i < P3DMesh[m].NumVertices; i++ ){ P3DMesh[m].Vertex[i].Y = -1*(P3DMesh[m].Vertex[i].Y + P3DMesh[m].LocalPos.Y) - P3DMesh[m].LocalPos.Y; }
       }
       for( i = 0; i < P3DNumLights; i++ ){   P3DLight[i].Pos.Y = -P3DLight[i].Pos.Y; }
   }
   if( Options.MirrorZ )
   {
       for( int m = 0; m < P3DNumMeshes; m++ )
       {
          for( i = 0; i < P3DMesh[m].NumVertices; i++ ){ P3DMesh[m].Vertex[i].Z = -1*(P3DMesh[m].Vertex[i].Z + P3DMesh[m].LocalPos.Z) - P3DMesh[m].LocalPos.Z; }
       }
       for( i = 0; i < P3DNumLights; i++ ){   P3DLight[i].Pos.Z = -P3DLight[i].Pos.Z; }
   }

    
   if( (Options.MirrorX + Options.MirrorY + Options.MirrorZ) % 2 == 1 )  // Ungerade Anz. an Mirror verursacht Poly-
   {                                                                     // "umst�lpung". �ndere Swappingwert daf�r
       Options.SwapPolyOrder = 1 - Options.SwapPolyOrder;
   }


   // Polyorder umdrehen
   int   TempP;
   float TempU, TempV;
   if( Options.SwapPolyOrder )
   {
       for( int m = 0; m < P3DNumMeshes; m++ )
       {
           for( i = 0; i < P3DMesh[m].NumPolys; i++ )          // Swappe die Polypunkte
           {
               TempP = P3DMesh[m].Poly[i].P2;
               TempU = P3DMesh[m].Poly[i].U2;
               TempV = P3DMesh[m].Poly[i].V2;

               P3DMesh[m].Poly[i].P2 = P3DMesh[m].Poly[i].P3;
               P3DMesh[m].Poly[i].U2 = P3DMesh[m].Poly[i].U3;
               P3DMesh[m].Poly[i].V2 = P3DMesh[m].Poly[i].V3;
    
               P3DMesh[m].Poly[i].P3 = TempP;
               P3DMesh[m].Poly[i].U3 = TempU;
               P3DMesh[m].Poly[i].V3 = TempV;
           }
       }
   }


    // Modell speichern
   _fmode = O_BINARY;
     

   if( !Options.ShaderTest )  // Jetzt k�nnen wir P3D sichern
   {   
       save_to_p3d();    
   }
   else                       // Der Shadertest konvertiert das Modell mit allen vorhandenen Texturen
   {
       struct find_t   FileInfo;
       int             Return;
       String          TempString;

       /// Z�hle die dort vorhandenen Dateien    
       CDDir->GoToDirectory ( "TEXTURES" );
       Return = _dos_findfirst( "*.tga", _A_NORMAL | _A_HIDDEN | _A_SYSTEM | _A_ARCH, &FileInfo );

       String OutBackup = output;
       do
       {
           output = "shadertest_";
           output += FileInfo.name;
           output += "_" + OutBackup;

           cout << "Writing shader test P3D '" + output + "'\n";

           for( int m = 0; m < P3DNumMeshes; m++ )
           {
              for( i = 0; i < P3DMesh[m].NumPolys; i++ )          // Swappe die Polypunkte
              {
                   P3DMesh[m].Poly[i].Texture = FileInfo.name;
              }
           }

           save_to_p3d();
       }
       while( _dos_findnext( &FileInfo ) == 0 );
   }
   
}



// ����������������������������������������������������������������������������
int save_to_p3d()
// ����������������������������������������������������������������������������
{


       // Fehler abfangen
       for( int m = 0; m < P3DNumMeshes; m++ )
       {
           if( P3DMesh[m].NumVertices >= P3DMANAG_MAXVERTICES )
           {
               SetConsoleColor( CONCOL_RED );
               cout << "\nMeshes in P3D files cannot have more than 32768 vertices!";
               getch();
               exit(0);
           }
        
           if( P3DMesh[m].NumPolys >= P3DMANAG_MAXPOLYS )
           {
               SetConsoleColor( CONCOL_RED );
               cout << "\nMeshes in P3D files cannot have more than 32768 polys!";
               getch();
               exit(0);
           }
       }
        
       if( P3DNumLights >= P3DMANAG_MAXLIGHTS )
       {
           SetConsoleColor( CONCOL_RED );
           cout << "\nP3D files cannot have more than 255 lights!";
           getch();
           exit(0);
       }
    

//       CDDir->GoToDirectory ( "EDITOR" );
       if( GetPathFromString( output ) != "" )                  // Hat Autopfad, aber nicht
       {
          output = "../trkdata/cars/" + output;
       }
       else
       {
           output = CDDir->GetCrashdayDirectory() + "/editor/" + output;
       }



       if( access( output, F_OK ) == 0 && Options.Overwrite == 0 && Options.ShaderTest == 0 )   // Datei schon vorhanden oder keine Abfrage
       {
          SetConsoleColor( CONCOL_GREEN );
          cout << "\n\nOutput file exists. Overwrite? (Y/N)";
    
          char Key = getch();
          if( Key != 'Y' && Key != 'y' )
          {
              SetConsoleColor( CONCOL_RED );
              cout << "\nNot overwritten!";
              delete CDLog;
              return 0;
          }
          else
          {
              SetConsoleColor( CONCOL_GREEN );
              cout << "\nOK to overwrite!\n\n";
          }
    
      }
   

      SaveP3DFile( output );    // Benutze P3DMANAG-Funktion zum Speicher
      return 0;                // Alles OK
}




// ����������������������������������������������������������������������������
int main(int argc, char** argv)
// ����������������������������������������������������������������������������
{

    SetConsoleColor( CONCOL_YELLOW );
    cout << "\n\n\n-------------------------\n   3DS to P3D converter\n-------------------------\n";



    CDLog = new Log( "makep3d.log" );          // Logfile

    chdir( "../.." );                          // Hole Crshpath.ini aus ROOT
    CDDir = new CrashdayDirectory();           // Pfadinformationen

    CDDir->GoToDirectory( "EDITOR" );




    Lib3dsFile *f=0;

    SetConsoleColor( CONCOL_DEFAULT );
    parse_args(__argc, __argv);

    
    input = AddFilenameExtensionIfMissing( input, "3ds" );
    output = AddFilenameExtensionIfMissing( output, "p3d" );


    CDDir->GoToDirectory ( "EDITOR" );
    if( GetPathFromString( input ) != "" )                  // Hat Autopfad, aber nicht
    {
         input = "../trkdata/cars/" + input;
    }

    SetConsoleColor( CONCOL_DEFAULT );
    cout << "\nScanning input file " << input << "..." << endl;

    f = lib3ds_file_load(input);

    if (!f)
    {
      SetConsoleColor( CONCOL_RED );
      fprintf(stderr, "Error!\nLoading file %s failed\n", input);
      getch();
      exit(1);
    }

    SetConsoleColor( CONCOL_DEFAULT );
    cout << "Writing p3d file " << output << "..." << endl;
    convert_to_p3d(f, input);

    cout << "program terminated\n";

    getch();

    delete CDLog;
    return 0;

}



