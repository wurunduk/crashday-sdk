// ==================================================================
//
//   path.hpp  -  Diese Datei enth�lt die Definition
//                der CrashdayDirectory-Klasse, die
//                f�r richtige Pfadangaben wichtig ist
//
//   Autor:    Robert Clemens
//   Start:    16.3.99
//
// ==================================================================

#ifndef _PATH_HPP_INCLUDED_

#define _PATH_HPP_INCLUDED_

#include "debug.hpp"              // Zur Fehlerbehandlung
#include "log.hpp"                // F�r LogFile
#include <fstream>                // F�r Fileobjekt
#include <string.hpp>      


#define  MAX_DIRECTORY_CHARS     256

// CrashdayDirectory-Klasse
// Die Installation legt im Crashday-Root-Verzeichnis die Datei
// "CrshPath.txt" ab, die den Crashdaypfad enth�lt.
// Ben�tigt eine Funktion das Verzeichnis, kann es diese Funktionen aufrufen

class CrashdayDirectory
{
     public:    // ------------------------------------

         CrashdayDirectory();           // Konstruktor, l�dt Pfad aus "CrshPath.txt"
         ~CrashdayDirectory();          // Destruktor

         String GetCrashdayDirectory() const;      // Zur�ckliefern des Crashday-Pfades
         int   GoToDirectory( String );            // CD-Pfad + String(z.B.TOOLS)
                                                   // Geht in das Verzeichnis, was im
                                                   // Crashday-Verzeichnis liegen mu�

     private:  // ------------------------------------

         String   Directory;      // Zeiger auf das Verzeichnis
};


extern  CrashdayDirectory*  CDDir;   // Allgemeines Objekt f�r Verzeichnisse


#endif   // path.hpp
