// ==================================================================
//
//   filename.cpp - Kleine Hilfefunktionen f�r die Arbeit mit
//                  Dateinamen
//
//   Autor:    Robert Clemens
//   Start:    28.02.03
//
// ==================================================================

#include "filename.hpp"
#include "debug.hpp"

#include <direct>



// GetFilenameFromString ( extrahiert aus einem Pfad+Dateinamen den Dateinamen )
// =============================================================================

String GetFilenameFromString( String str )
{

     String RetStr = "";
     for( int i = str.length()-1; str[i] != '/' && i > 0 ; i-- )   // Suche das erste "/" von hinten
     {
           // Bricht automatisch ab wenn von hinten das erste "/"
           // gefunden wird
     }

     if( i == 0 ){ return str; }                                   // Name enth�lt keinen Pfad


     for( int j = i+1; j < str.length(); j++ )                     // Baue Filename auf
     {
          RetStr += str[j];
     }

     return RetStr;
}



// GetPathFromString ( extrahiert aus einem Pfad+Dateinamen den Pfad )
// ===================================================================

String GetPathFromString( String str )
{

     String RetStr = "";
     for( int i = str.length()-1; str[i] != '/' && i > 0 ; i-- )   // Suche das erste "/" von hinten
     {
           // Bricht automatisch ab wenn von hinten das erste "/"
           // gefunden wird
     }

     if( i == 0 ){ return ""; }                                    // Name enth�lt keinen Pfad


     for( int j = 0; j <= i; j++ )                                 // Baue Pfad auf (nimm "/" noch mit rein)
     {
          RetStr += str[j];
     }

     return RetStr;
}



// GetFilenameExtension ( liefert die Erweiterung eines Dateinamens )
// ==================================================================

String GetFilenameExtension( String str )
{

    //_ASSERT( str.length() > 4 );
    //_ASSERT( str[str.length()-4] == '.' );

    String Ret = str[str.length()-3];
    Ret += str[str.length()-2];
    Ret += str[str.length()-1];
    
    return Ret;
}



/// AddFilenameExtensionIfMissing ( f�ge eine Erweiterung an den Dateinamen an, falls sie fehlt )
/// =============================================================================================

String AddFilenameExtensionIfMissing( String str, String newext )
{
    if( str.length() > 4 && str[str.length()-4] == '.' )  // Wir vermuten dass das hier eine Extension ist, deshalb ok!
    {
        return str;
    }
    
    return (str + "." + newext);
}



// ChangeFilenameExtension ( �ndert die Erweiterung eines Dateinamens )
// ====================================================================

String ChangeFilenameExtension( String str, String newext )
{

   _ASSERT( str.length() > 4 );
   _ASSERT( newext.length() == 3 );

    str[str.length()-3] = newext[0];
    str[str.length()-2] = newext[1];
    str[str.length()-1] = newext[2];

    return str;
}



// RemoveFilenameExtension ( entfernt die Erweiterung eines Dateinamens )
// ======================================================================

String RemoveFilenameExtension( String str )
{

    _ASSERT( str.length() > 4 );

     String RetStr = "";
     for( int i = 0; i < str.length()-4; i++ )
     {
         RetStr += str[i];
     }

     return RetStr;
}


/*
// IsStringInCarFolder ( liefert ob der Name im String einem Autoordner in /trkdata/cars/ entspricht )
// ===================================================================================================

char IsStringCarFolder( String str, String  )
{

    DIR*    Dir;                 // Verzeichnisinfos f�r Autos
    dirent* DirEntry;
    String  ListName;


    CDDir->GoToDirectory( "TRKDATA/CARS/" );  // Autos im Verzeichnis z�hlen
    Dir = opendir( "../cars/" );

    if( Dir == NULL )
    {
       _ERROR( "Error in IsStringInCarFolder() function!\nCan't find any cars!\n" );
    }


    // Alle Ordner durchlaufen
    for( ;; )
    {
        DirEntry = readdir( Dir );                               // N�chsten Ordner lesen

        if( DirEntry == NULL ){ break; }
        if( !(DirEntry->d_attr & _A_SUBDIR) ){ continue; }

        ListName = DirEntry->d_name;
        ListName = ListName.lower();
        
        if( ListName == str ){ closedir( Dir ); return 1; }     // Hier ist unser Ordner
    }

    closedir( Dir );


    return 0;   // Nein, kein Autoordner
}
*/
