// Clean Little Helper
// Autor: Robert Clemens

#include <stdio>
#include <string.hpp>
#include <graph>
#include <conio>
#include <math>
#include <stdlib>
#include <direct>
#include <fcntl>
#include <dos>
#include <io>


#include "log.hpp"      // Logfile
#include "path.hpp"     // Pfadangaben
#include "filename.hpp" // Dateinamen

#include "../p3dmanag/p3dmanag.hpp"    // Benutze P3D-Management-Funktionen


#define  RAD  6.283185


P3DVALUE M[3][3];  // Rotationsmatrix


// SaveObject ( speichert Objekt in 'filename' )
// =============================================

int SaveObject( String filename, char overwrite )
{

   if( (overwrite != 0) && (overwrite != 1) ){ overwrite = 0; }


   if( GetPathFromString( filename ) != "" )
   {
       filename = "../trkdata/cars/" + filename;
   }


   // Wenn Datei vorhanden und nicht �berschrieben werden soll, mit -1 beenden
   if( (access( filename, F_OK ) == 0) && (overwrite == 0) )
   {
       return -1;
   }


   SaveP3DFile( filename );  // Benutze P3D-Saving
   return 0;     
}




// LoadObject ( l�dt Objekt aus 'filename' )
// =========================================

int LoadObject( String filename )
{

   if( GetPathFromString( filename ) != "" )
   {
       filename = "../trkdata/cars/" + filename;
   }

   // Wenn Datei nicht vorhanden, mit -1 beenden
   if( access( filename, F_OK ) != 0 )
   {
       return -1;
   }


   LoadP3DFile( filename );  // Benutze P3D-Load
   return 0;     
}




// ShiftObject ( verschiebt das Objekt )
// =====================================

void ShiftObject( float x, float y, float z )
{

   for( int i = 0; i < P3DNumVertices; i++ )
   {
       P3DVertex[i].X += x;
       P3DVertex[i].Y += y;
       P3DVertex[i].Z += z;
   }

   for( i = 0; i < P3DNumLights; i++ )
   {
       P3DLight[i].Pos.X += x;
       P3DLight[i].Pos.Y += y;
       P3DLight[i].Pos.Z += z;
   }

}



// RotateObject ( rotiert das Objekt )
// ===================================

void RotateObject( float x, float y, float z )
{
   
    float SinA, CosA, SinB, CosB, SinC, CosC;  // Sinus und Cosinus der Winkel

    CosB = cos( (x*RAD/360) );
    SinB = sin( (x*RAD/360) );
    CosC = cos( (y*RAD/360) );
    SinC = sin( (y*RAD/360) );
    CosA = cos( (z*RAD/360) );
    SinA = sin( (z*RAD/360) );

    // 1. Maxtrixreihe
    M[0][0] = CosA * CosC - SinA * SinB * SinC;
    M[0][1] = SinA * CosC + CosA * SinB * SinC;
    M[0][2] = CosB * SinC;

    // 2. Matrixreihe
    M[1][0] = -SinA *CosB;
    M[1][1] = CosA *CosB;
    M[1][2] = -SinB;

    // 3. Matrixreihe
    M[2][0] = -CosA * SinC - SinA * SinB * CosC;
    M[2][1] = -SinA * SinC + CosA * SinB * CosC;
    M[2][2] = CosB * CosC;


    P3DVERTEX VectorCopy;
    for( int i = 0; i < P3DNumVertices; i++ )  
    {
         VectorCopy.X = P3DVertex[i].X;  // Matrix und Vertex multiplizieren
         VectorCopy.Y = P3DVertex[i].Y;
         VectorCopy.Z = P3DVertex[i].Z;
 
         P3DVertex[i].X = (VectorCopy.X * M[0][0]) + (VectorCopy.Y * M[1][0]) + (VectorCopy.Z * M[2][0]);
         P3DVertex[i].Y = (VectorCopy.X * M[0][1]) + (VectorCopy.Y * M[1][1]) + (VectorCopy.Z * M[2][1]);
         P3DVertex[i].Z = (VectorCopy.X * M[0][2]) + (VectorCopy.Y * M[1][2]) + (VectorCopy.Z * M[2][2]);
    }

    for( i = 0; i < P3DNumLights; i++ )
    {
         VectorCopy.X = P3DLight[i].Pos.X;  // Matrix und Vertex multiplizieren
         VectorCopy.Y = P3DLight[i].Pos.Y;
         VectorCopy.Z = P3DLight[i].Pos.Z;
 
         P3DLight[i].Pos.X = (VectorCopy.X * M[0][0]) + (VectorCopy.Y * M[1][0]) + (VectorCopy.Z * M[2][0]);
         P3DLight[i].Pos.Y = (VectorCopy.X * M[0][1]) + (VectorCopy.Y * M[1][1]) + (VectorCopy.Z * M[2][1]);
         P3DLight[i].Pos.Z = (VectorCopy.X * M[0][2]) + (VectorCopy.Y * M[1][2]) + (VectorCopy.Z * M[2][2]);
    }


      // Packe "kleinsten" Punkt auf Ursprung (ziehe andere Punkte nach)
      float lowx, lowy, lowz;
      lowx = P3DVertex[0].X;
      lowy = P3DVertex[0].Y;
      lowz = P3DVertex[0].Z;

      for( i = 0; i < P3DNumVertices; i++ )  // Finde "kleinsten" Punkt
      {
            if( P3DVertex[i].X < lowx ){ lowx = P3DVertex[i].X; }
            if( P3DVertex[i].Y < lowy ){ lowy = P3DVertex[i].Y; }
            if( P3DVertex[i].Z > lowz ){ lowz = P3DVertex[i].Z; }  // Bei Z nach gr��tem Punkt suchen
      }

      for( i = 0; i < P3DNumVertices; i++ )  // Verschiebe
      {
            P3DVertex[i].X -= lowx;
            P3DVertex[i].Y -= lowy;
            P3DVertex[i].Z -= lowz;
      }

      for( i = 0; i < P3DNumLights; i++ )    // Verschiebe
      {
            P3DLight[i].Pos.X -= lowx;
            P3DLight[i].Pos.Y -= lowy;
            P3DLight[i].Pos.Z -= lowz;
      }



      if( (x == -90 || x == 90 || x == 270) && y == 0 && z == 0 )     // 90/270-Grad um X-Achse
      {
          float Swap = P3DHeight;
          P3DHeight = P3DDepth;
          P3DDepth = Swap;
      }

      if( (y == -90 || y == 90 || y == 270) && x == 0 && z == 0 )     // 90/270-Grad um Y-Achse
      {
          float Swap = P3DLength;
          P3DLength = P3DDepth;
          P3DDepth = Swap;
      }

      if( (z == -90 || z == 90 || z == 270) && x == 0 && y == 0 )     // 90/270-Grad um Z-Achse
      {
          float Swap = P3DHeight;
          P3DHeight = P3DLength;
          P3DLength = Swap;
      }
}



// MirrorPolys ( spiegelt die Polys )
// ==================================

void MirrorPolys()
{
   int   TempP;
   float TempU, TempV;

   for( int i = 0; i < P3DNumPolys; i++ )          // Swappe die Polypunkte
   {
       TempP = P3DPoly[i].P2;
       TempU = P3DPoly[i].U2;
       TempV = P3DPoly[i].V2;

       P3DPoly[i].P2 = P3DPoly[i].P3;
       P3DPoly[i].U2 = P3DPoly[i].U3;
       P3DPoly[i].V2 = P3DPoly[i].V3;

       P3DPoly[i].P3 = TempP;
       P3DPoly[i].U3 = TempU;
       P3DPoly[i].V3 = TempV;
   }
}



// ScaleObject ( scaliert das Objekt )
// ===================================

void ScaleObject( float x, float y, float z )
{

   for( int i = 0; i < P3DNumVertices; i++ )
   {
       P3DVertex[i].X *= x;
       P3DVertex[i].Y *= y;
       P3DVertex[i].Z *= z;
   }

   for( i = 0; i < P3DNumLights; i++ )
   {
       P3DLight[i].Pos.X *= x;
       P3DLight[i].Pos.Y *= y;
       P3DLight[i].Pos.Z *= z;
   }

      // Packe "kleinsten" Punkt auf Ursprung (ziehe andere Punkte nach)
      float lowx, lowy, lowz;
      lowx = P3DVertex[0].X;
      lowy = P3DVertex[0].Y;
      lowz = P3DVertex[0].Z;

      for( i = 0; i < P3DNumVertices; i++ )  // Finde "kleinsten" Punkt
      {
            if( P3DVertex[i].X < lowx ){ lowx = P3DVertex[i].X; }
            if( P3DVertex[i].Y < lowy ){ lowy = P3DVertex[i].Y; }
            if( P3DVertex[i].Z > lowz ){ lowz = P3DVertex[i].Z; }  // Bei Z nach gr��tem Punkt suchen
      }

      for( i = 0; i < P3DNumVertices; i++ )  // Verschiebe
      {
            P3DVertex[i].X -= lowx;
            P3DVertex[i].Y -= lowy;
            P3DVertex[i].Z -= lowz;
      }

      for( i = 0; i < P3DNumLights; i++ )    // Verschiebe
      {
            P3DLight[i].Pos.X -= lowx;
            P3DLight[i].Pos.Y -= lowy;
            P3DLight[i].Pos.Z -= lowz;
      }


   P3DLength *= fabs(x);
   P3DHeight *= fabs(y);
   P3DDepth *= fabs(z);


   // Achtung: Polys k�nnten sich "umst�lpen"
   if( x*y*z < 0 ){ MirrorPolys(); }
}



// Hauptprogramm
// =============
void main()
{
    char       Key = 0;       // Benutzereingabe
    String      filename = ""; // Dateiname
    String      test;          // Teststring
    P3DVERTEX   Vector;        // Vektor f�r verschiedene Aufgaben

    CDLog = new Log( "clh.log" );

    chdir( "../.." );
    CDDir = new CrashdayDirectory();
    CDDir->GoToDirectory( "EDITOR" );


    for( ;; )  // Schleifenstart
    {

      // Anfangsschrift
     _clearscreen( _GCLEARSCREEN );
      cout << "   -- Clean Little Helper V1.5 --\n\nZusatztool fuer CrashEdit\nBy Robert Clemens\n";
      cout << "\n\nGeladenes Modell: " << filename << "\n";
      cout << "\nWhat do you want to do today? :\n\n";
      cout << "\t(1) Modell laden\n";
      cout << "\t(2) Modell speichern\n";
      cout << "\t(3) Modell verschieben\n";
      cout << "\t(4) Modell rotieren\n";
      cout << "\t(5) Modell scalen\n";
      cout << "\t(6) Polygone spiegeln\n";
   
      Key = getch();  

      switch( Key )
      {
        case 27:  // Esc - Beenden
                   delete CDDir;
                   delete CDLog;
                   exit(0);

        case 49:  // 1 - laden
                   cout << "\nModell laden...\nDateiname:\t";
                   cin  >> test;
                   if( LoadObject( test ) != 0 )
                   {
                      cout << "\nDatei nicht vorhanden!\n"; getch();
                   }
                   else
                   {
                       filename = test;
                   }
                   sound(1000); delay(10); nosound();
                   break;

        case 50:  // 2 - speichern
                   cout << "\nModell speichern...\nDateiname:\t";
                   cin  >> test;
                   if( SaveObject( test, 0 ) != 0 )
                   {
                       cout << "\nVorhandene Datei ueberschreiben? (J\N): ";
                       Key = getch();
                       if( Key == 'j' || Key == 'J' )
                       {
                           SaveObject( test, 1 );
                           filename = test;
                       }
                   }
                   else
                   {
                       filename = test;
                   }
                   sound(1000); delay(10); nosound();
                   break;

        case 51:  // 3 - verschieben
                   cout << "\nModell verschieben...\n";
                   cout << "X-Verschiebung: ";
                   cin  >> Vector.X;
                   cout << "\nY-Verschiebung: ";
                   cin  >> Vector.Y;
                   cout << "\nZ-Verschiebung: ";
                   cin  >> Vector.Z;
                   ShiftObject( Vector.X, Vector.Y, Vector.Z );
                   sound(1000); delay(10); nosound();
                   break;

        case 52:  // 4 - rotieren
                   cout << "\nModell rotieren...(360 Grad Vollkreis)\n";
                   cout << "X-Rotation: ";
                   cin  >> Vector.X;
                   cout << "\nY-Rotation: ";
                   cin  >> Vector.Y;
                   cout << "\nZ-Rotation: ";
                   cin  >> Vector.Z;
                   RotateObject( Vector.X, Vector.Y, Vector.Z );
                   sound(1000); delay(10); nosound();
                   break;

        case 53:  // 5 - skalieren
                   cout << "\nModell skalieren...\n";
                   cout << "X-Scaling: ";
                   cin  >> Vector.X;
                   cout << "\nY-Scaling: ";
                   cin  >> Vector.Y;
                   cout << "\nZ-Scaling: ";
                   cin  >> Vector.Z;
                   ScaleObject( Vector.X, Vector.Y, Vector.Z );
                   sound(1000); delay(10); nosound();
                   break;

        case 54:  // 6 - skalieren
                   cout << "\nPolygone gespiegelt\n";
                   MirrorPolys();
                   sound(1000); delay(10); nosound();
                   break;
       }
    }
}
