// ==================================================================
//
//   path.cpp  -  Diese Datei enth�lt die Implentierung f�r
//                die CrashdayDirectory-Klasse, die
//                f�r richtige Pfadangaben wichtig ist
//
//   Autor:    Robert Clemens
//   Start:    16.3.99
//
// ==================================================================

#include "path.hpp"               // F�r Klassendefinition
#include "debug.hpp"              // Zur Fehlerbehandlung
#include "textfile.hpp"           // Zum Linienauslesen
#include "log.hpp"

#include <direct>       // F�r chdir
#include <io>           // F�r access


CrashdayDirectory*  CDDir;      // Allgemein zu nutzendes Objekt f�r die Verzeichnisse


// Konstruktor ( �ffnet Datei und liest Pfad aus )
// ===============================================

CrashdayDirectory::CrashdayDirectory()
{

   #ifdef LOG
      CDLog->Input( "Create CrashdayDirectory object...\n" );
      CDLog->Input( "Read game directory from 'crshpath.txt'...\n" );
   #endif


   /// File-Check
   if( access( "crshpath.ini", F_OK ) != 0 )  
   {
        _ERROR( "File 'crshpath.ini' in supposed Crashday installation directory could not be found!\n" );
   }


   /// Verzeichnis auslesen
   FILE* CDPath = fopen( "crshpath.ini", "r" );

   ReadTextLine( CDPath );                        // Freizeile
   String FullLine = ReadTextLine( CDPath );      // N�chste Zeile erstmal komplett lesen

   for( int i = 0; i < FullLine.length(); i++ )
   {
       if( FullLine[i] == '=' ){ break; }  // Hier beginnt der Pfad
   }

   i++;

   Directory = "";
   for( ; i < FullLine.length(); i++ )           // Nach '=' folgt unser Pfad
   {
       if( i < FullLine.length()-1 || FullLine[i] != '\\' )
       {
          Directory += FullLine[i];
       }
   }

   Directory = Directory.upper();
   fclose( CDPath );    


   /// 2.File-Check
   if( access( Directory, F_OK ) != 0 )  
   {
        _ERROR_M( "File 'crshpath.ini': The game directory doesn't exist!\n", Directory );
   }

   #ifdef LOG
      CDLog->Input( "Crashday directory: " );
      CDLog->Input( Directory );
      CDLog->Input( "\n\n" );
   #endif

}


// Destruktor
// ==========

CrashdayDirectory::~CrashdayDirectory()
{

   #ifdef LOG
      CDLog->Input( "\nDirectory object shut down\n" );
   #endif

}


// GetCrashdayDirectory ( Verzeichnis als String zur�ckliefern )
// =============================================================

String CrashdayDirectory::GetCrashdayDirectory() const
{
    return Directory;
}


// GoToDirectory ( In ein Unterverzeichnis vom Crashdayordner gehen )
// ==================================================================

int CrashdayDirectory::GoToDirectory( String directory )
{

   chdir( Directory );  // Ins Crashday-Verzeichnis

   // Es wurde das Root-Verzeichnis verlangt
   if( strcmp( directory, "ROOT" ) == 0 )
   {
       return 0;
   }

   // Test, ob Unterverzeichnis vorhanden ist
   if( access( directory, F_OK ) != 0 )  
   {
       #ifdef DEBUG
          _ERROR_M( "Requested subdirectory not found in Crashday folder!", directory );
       #endif
       return -1;
   }

   #ifdef LOG
      CDLog->Input( "Changing to directory '" );
      CDLog->Input( directory );
      CDLog->Input( "'...\n" );
   #endif
    
   chdir( directory );          // Ins Unterverzeichnis
   return 0;                   // Alles ok!

}



