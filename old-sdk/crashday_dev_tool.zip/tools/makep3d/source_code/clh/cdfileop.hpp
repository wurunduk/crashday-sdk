// ==================================================================
//
//   cdfileop.hpp  - Diese Datei deklariert die Crashday-Dateifunktionen,
//                   die den WATCOM-Funktionen entsprechen, doch zus�tzlich
//                   ein De/EnCrypt-Bittausch auf die Daten ausf�hren, um
//                   verschl�sselte ASCII-Files zur�ckzusetzen
//
//   Autor:    Robert Clemens
//   Start:    2.7.99
//
// ==================================================================

#ifndef _CDFILEOP_HPP_INCLUDED_

#define _CDFILEOP_HPP_INCLUDED_


#include "debug.hpp"   // Zur Fehlerbehandlung

#include <stdio.h>     // Fileop-Headers
#include <string.h>
#include <string.hpp>
#include <fcntl.h>
#include <stdlib.h>
#include <errno.h>
#include <io.h>


//#define ENABLE_CDCRYPT                // Entscheidet, ob das Cryptsystem aktiv sein soll
#define  DONT_WRITESTRINGNULL        1  // Beim Schreiben von Strings in eine File soll die Schluss-NULL fehlen


// Status des CDCryptsystems
enum CDCRYPTSTATE
{
    CDCRYPT_NONE  = 0,    // Verwendet kein CDCrypt
    CDCRYPT_READ  = 1,    // Verwendet es beim Laden
    CDCRYPT_WRITE = 2,    // Verwendet es beim Schreiben
    CDCRYPT_BOTH  = 3     // Verwendet CDCrypt beim Lesen & Schreiben
};


int   CDfopen( String filename, String mode, CDCRYPTSTATE state );  // �ffnet eine Datei
int   CDfclose();                                                   // Schlie�t diese
int   CDfseek( long offset, int where );                           // Setzt Dateicursor
int   CDftell();                                                    // Liefert Dateicursor

FILE*  CDgetfp();                                                    // Liefert Filepointer

int    CDfread( void* buf, size_t elsize, size_t nelem );          // Liest aus einer Datei
int    CDfwrite( void* buf, size_t elsize, size_t nelem );         // Schreibt in eine Datei 

int    CDfgetc();                                                   // Schreibt/Liest einzelnes
int    CDfputc( int c );                                            // Zeichen

int    CDfreadstring( String* str );                                // Liest einen String
int    CDfwritestring( String* str, int nonull = 0 );               // Schreibt einen String

int    CDfwritereturn();                                            // Schreibt einen Returnzeichen in eine File

int    CDfreadwholefile( void** buf, size_t* fsize );               // Liest eine gesamte Datei in einen Puffer

int    CDfeof();                                                    // Testet auf das Ende der File
int    CDferror();                                                  // Testet auf einen Fehler

                                        
#endif   // cdfileop.hpp


