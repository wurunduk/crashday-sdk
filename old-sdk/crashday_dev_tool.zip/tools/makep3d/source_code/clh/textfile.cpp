// ==================================================================
//
//   textfile.cpp  -  Diese Datei definiert die Funktionen zur Arbeit
//                    mit Textdateien
//
//   Autor:    Robert Clemens
//   Start:    23.6.99
//
// ==================================================================

#include "textfile.hpp"
#include <stdlib>

signed char TextLine[2048];    /// Diese Charlist nimmt eine gelesene Textzeile auf, in jedem
                                /// Fall mu� die Textzeile weniger als 2048 Zeichen lang sein
signed char TotalLine[2048];   /// Der aktuell gelesene Teil liegt hier


String  ReadTextLine( FILE* fp )
// -----------------------------
{
   _fmode = O_BINARY;

    int  SaveUntil = 0;
    int  IntTemp;

    /// Alles mit '\0' f�llen
    bzero( &TextLine[0], 2048 );
    bzero( &TotalLine[0], 2048 );


    for( int i = 0; i < 2047; i++ ) /// Textzeile auslesen
    {
        IntTemp = fgetc( fp );
        if( IntTemp == EOF ){ TotalLine[i] = '\0'; break; }     /// EOF

        TotalLine[i] = (signed char) IntTemp;

        if( TotalLine[i] == 9 ){ TotalLine[i] = 32; }            /// Mache Tabs zu Spaces
        if( i == 0 && TotalLine[i] == 32 ){ i--; continue; }    /// �berspringe Spaces am Anfang


        if( TotalLine[i] != 0 && TotalLine[i] != 0x0D && TotalLine[i] != 0x0A &&   /// Ist kein Sonderzeichen
            TotalLine[i] != '#' )
        {
            SaveUntil = i+1;
        }

        if( TotalLine[i] == '#' ){ do { IntTemp = fgetc( fp ); } while( IntTemp != 0x0D && IntTemp != EOF ); fgetc( fp ); break; }  /// Lies bis RETURN
        if( TotalLine[i] == 0x0A ){ fgetc( fp ); break; }                                    /// Return
    }


    /// Entferne Spaces/Tabs am Ende
    while( SaveUntil > 0 && (TotalLine[SaveUntil-1] == 32 || TotalLine[SaveUntil-1] == 9) )
    {
        SaveUntil--;
    }


    if( SaveUntil == 0 ){ return ""; }   /// Nix in der Zeile


    /// Kopiere die sicheren Zeichen
    memcpy( &TextLine[0], &TotalLine[0], SaveUntil );

    String ReturnString = (char* const) &TextLine[0];
    return ReturnString;
}

 

String  ReadWord( FILE* fp )
// -------------------------
{
   _fmode = O_BINARY;

    int          SaveUntil = 0;
    int          IntTemp;
    signed char Temp;

    /// Alles mit '\0' f�llen
    bzero( &TextLine[0], 2048 );
    bzero( &TotalLine[0], 2048 );


    for( int i = 0; i < 2047; i++ ) /// Textzeile auslesen
    {
        IntTemp = fgetc( fp );
        if( IntTemp == EOF ){ TotalLine[i] = '\0'; break; }     /// EOF

        TotalLine[i] = (signed char) IntTemp;

        if( TotalLine[i] == 9 ){ TotalLine[i] = 32; }            /// Mache Tabs zu Spaces
        if( i == 0 && TotalLine[i] == 32 ){ i--; continue; }    /// �berspringe Spaces am Anfang
        

        if( TotalLine[i] != 0 && TotalLine[i] != 0x0D && TotalLine[i] != 0x0A &&
            TotalLine[i] != 32 && TotalLine[i] != '#' )
        {
            SaveUntil = i+1;
        }


        if( TotalLine[i] == '#' ){ do {} while( fgetc( fp ) != 0x0A ); break; }  /// Comment
        if( TotalLine[i] == 0x0A ){ break; }                                    /// Return

        if( TotalLine[i] == 32 )                                                 /// Stoppe bei Space
        {
            do
            {
               Temp = fgetc( fp );
               if( Temp == 9 ){ Temp = 32; }            /// Mache Tabs zu Spaces
            }
            while( Temp == 32 );
            if( Temp == '#' ){ do { IntTemp = fgetc( fp ); } while( IntTemp != 0x0D && IntTemp != EOF ); fgetc( fp ); }  /// Comment
            else
            if( Temp == 0x0D ){ fgetc( fp ); }                                    /// Return
            else                                                                
            { fseek( fp, -1, SEEK_CUR ); }                                         /// Sonstiges Zeichen, also zur�ck
            break;
        }
      
    }


    if( SaveUntil == 0 ){ return ""; }   /// Nix in der Zeile


    /// Kopiere die sicheren Zeichen
    memcpy( &TextLine[0], &TotalLine[0], SaveUntil );

    String ReturnString = (char* const) &TextLine[0];
    return ReturnString;
}
 
