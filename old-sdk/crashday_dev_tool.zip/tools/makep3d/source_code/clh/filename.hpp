// ==================================================================
//
//   filename.hpp - Kleine Hilfefunktionen zur Arbeit mit Dateinamen
//
//   Autor:    Robert Clemens
//   Start:    28.01.02
//
// ==================================================================

#ifndef _FILENAME_HPP_INCLUDED_

#define _FILENAME_HPP_INCLUDED_


#include <string.hpp>



// Extrahiert aus einem Pfad+Dateinamen den Dateinamen
// ===================================================
String GetFilenameFromString( String str );


// Extrahiert aus einem Pfad+Dateinamen den Pfad
// =============================================
String GetPathFromString( String str );


// Extrahiert aus einem Dateinamen die Erweiterung
// ===============================================
String GetFilenameExtension( String str );


/// F�ge eine bestimmte Dateierweiterung zu, falls keine vorhanden ist
/// ==================================================================
String AddFilenameExtensionIfMissing( String str, String ext );


// �ndert die Erweiterung eines Dateinamens
// ========================================
String ChangeFilenameExtension( String str, String newext );


// Entfernt die Erweiterung eines Dateinamens
// ==========================================
String RemoveFilenameExtension( String str );

/*
// Ist der �bergebene Pfad ein Autoordner in trkdata/cars/
// =======================================================
char DoesSubfolderFolderExistInIsStringCarFolder( String str );
*/


#endif       // filename.hpp
