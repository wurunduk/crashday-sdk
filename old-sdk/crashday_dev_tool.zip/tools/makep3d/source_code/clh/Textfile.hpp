// ==================================================================
//
//   textfile.hpp  -  Diese Datei enth�lt Funktionen zur Arbeit
//                    mit Textdateien
//
//   Autor:    Robert Clemens
//   Start:    19.5.99
//
// ==================================================================

#ifndef _TEXTFILE_HPP_INCLUDED
#define _TEXTFILE_HPP_INCLUDED

#include <stdio.h>  
#include <string.h>
#include <string.hpp>
#include <fcntl.h>

String  ReadTextLine( FILE* fp );   // Funktion, die ganze Zeile aus Datei liest 
String  ReadWord( FILE* fp );       // Funktion, die ein Wort aus Datei liest 


#endif   // textfile.hpp
