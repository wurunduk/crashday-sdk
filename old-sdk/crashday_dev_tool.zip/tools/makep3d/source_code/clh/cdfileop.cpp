// ==================================================================
//
//   cdfileop.cpp  -  Diese Datei definiert die Fileoperation-
//                    Funktionen
//
//   Autor:    Robert Clemens
//   Start:    2.7.99
//
// ==================================================================

#include "cdfileop.hpp"    // Deklaration der Funktion
#include "debug.hpp"
#include <sys/stat>        // Filegr��e
#include <direct>          // Andere File-Fcts


// Interne Variablen
char         FileOpened = 0;

String        FileName = "";
FILE*         FilePointer = NULL;
CDCRYPTSTATE  FileCryptMode = CDCRYPT_NONE;

char         CryptBuffer[1024];  // Verschl�sselungsspeicher



// Crypt ( ver/entschl�sselt (Bittausch) der Bytefolge )
// =====================================================

void Crypt( void* buf, size_t length )
{

    char* Buf = (char*) buf;  // Buffer als char*

    __asm
    {

        mov edx, Buf      // Zu bearbeitende Adresse
        mov ecx, length   // Z�hler

      Go:                
        mov al,  [edx]    // Hole Byte nach al
        not al            // Bitswap :)
        mov [edx], al     // Zur�ck in Pointer

        inc  edx          // N�chstes Byte
        loop Go           // Weiter bis length = 0
    }
}



// CDfopen ( CD-Funktion zum �ffnen einer Datei )
// ==============================================

int CDfopen( String filename, String mode, CDCRYPTSTATE state )
{

   _fmode = O_BINARY;
     

    // Versuche den kompletten Pfad im Dateinamen aufzunehmen
    if( filename.length() >= 2 && filename[1] != ':' )             // Nimm an dass der Pfad fehlt
    {
        char*  Buffer;
        String Temp;

        Buffer = getcwd( NULL, 0 );
        Temp = &Buffer[0];
        Temp += '\\';

        filename = Temp + filename;
        free( Buffer );

        
    }



    // Wir k�nnen nur eine File gleichzeitig �ffnen
    if( FileOpened == 1 )  
    {
        _ERROR( "Error while opening file!\nCDFileOperations can only open one file at the same time!\n" );
    }


   _ASSERT( FilePointer == NULL );
    FilePointer = fopen( (char const*) filename, mode );  // Datei �ffnen


    // Error beim Laden der Datei
    if( FilePointer == NULL )  
    {
        _ERROR( "Error while opening file!\nFile pointer remains NULL! Probably the file doesn't exist or the file attributes are set wrong!" );
    }


    FileName = filename;    // Paramter merken
    FileCryptMode = state;
    FileOpened = 1;

    return 0;               // Alles ok!
}



// CDfclose ( CD-Funktion zum Schlie�en einer Datei )
// ==================================================

int CDfclose()
{

    if( FileOpened == 0 || FilePointer == NULL )  // Wir m�ssen eine File offen haben
    {
        _ERROR( "Error while closing file!\nTried to close an already closed file!" );
         return -1;
    }


    fclose( FilePointer );         // Datei schlie�en

    FileName = "";                 // Paramter merken
    FilePointer = NULL;
    FileCryptMode = CDCRYPT_NONE;
    FileOpened = 0;


    return 0;  // Alles ok!
}



// CDfseek ( CD-Funktion zum Setzen des Dateicursors in einer Datei )
// ==================================================================

int CDfseek( long offset, int where )
{

    if( FileOpened == 0 || FilePointer == NULL )  // Wir m�ssen eine File offen haben
    {
        _ERROR( "Error at CDfseek() in a file!\nNo file opened!" );
         return -1;
    }


    fseek( FilePointer, offset, where );        // Position setzen

    return 0;  // Alles ok!
}



// CDftell ( CD-Funktion zum Lesen des Dateicursors in einer Datei )
// =================================================================

int CDftell()
{

    if( FileOpened == 0 || FilePointer == NULL )  // Wir m�ssen eine File offen haben
    {
        _ERROR( "Error at CDftell() in a file!\nNo file opened!" );
         return -1;
    }


    return ftell( FilePointer );        // Position lesen
}



// CDgetfp ( CD-Funktion zur R�ckgabe des internen Filepointers )
// ==============================================================

FILE* CDgetfp()
{
    return FilePointer;
}



// CDfread ( CD-Funktion zum Lesen aus einer Datei )
// =================================================

int CDfread( void* buf, size_t elsize, size_t nelem )
{

    if( FileOpened == 0 || FilePointer == NULL )  // Wir m�ssen eine File offen haben
    {
        _ERROR( "Error at CDfread() in a file!\nNo file opened!" );
         return -1;
    }


    fread( buf, elsize, nelem, FilePointer );   // Daten lesen

    // Filecrypt ausf�hren
    #ifdef ENABLE_CDCRYPT
       if( FileCryptMode == CDCRYPT_BOTH || FileCryptMode == CDCRYPT_READ )
       {
           Crypt( buf, (nelem*elsize) );
       }
    #endif


    return 0;  // Alles ok!
}



// CDfreadstring ( CD-Funktion zum Lesen eines Strings aus einer Datei )
// =====================================================================

int CDfreadstring( String* str )
{

    if( FileOpened == 0 || FilePointer == NULL )  // Wir m�ssen eine File offen haben
    {
        _ERROR( "Error at CDfreadstring() in a file!\nNo file opened!" );
         return -1;
    }


   *str = "";

    for( int i = 0; ; i++ )
    {
        CryptBuffer[i] = fgetc( FilePointer );
        if( CryptBuffer[i] == 0 ){ break; }
    }

    // Filecrypt ausf�hren
    #ifdef ENABLE_CDCRYPT
       if( FileCryptMode == CDCRYPT_BOTH || FileCryptMode == CDCRYPT_READ )
       {
           Crypt( &CryptBuffer[0], i-1 );     // Gelese Bytes ohne Schluss-0
       }
    #endif


   *str = &CryptBuffer[0];      // Bytefolge in String kopieren
    return 0;                  // Alles ok!
}



// CDfreadwholefile ( CD-Funktion, die eine gesamte Datei in einen hier allokierten Buffer l�dt )
// ==============================================================================================

int CDfreadwholefile( void** buf, size_t* filesize )
{
 

    if( FileOpened == 0 || FilePointer == NULL )   // Wir m�ssen eine File offen haben
    {
        _ERROR( "Error at CDfreadwholefile() in a file!\nNo file opened!" );
         return -1;
    }



    int OldPos = CDftell();                        // Zum Anfang der File
    CDfseek( 0, SEEK_SET );


    struct stat FileStats;
    if( stat( FileName, &FileStats ) != 0 )       // Filestats mit Dateigr��e holen
    {
        _ERROR( "Error at CDfreadwholefile() in a file!\nCannot read the file stats. Permission denied!" );
         return -1;
    }

   *filesize = FileStats.st_size;

    

    // Neuen Buffer allokieren, um Daten auszulesen
   *buf = new char[ *filesize ];

    fread( *buf, 1, *filesize, FilePointer );  // Daten lesen
       

    CDfseek( OldPos, SEEK_SET );               // Alte Filepos restoren
    return 0;                                 // Alles ok!
}



// CDfwrite ( CD-Funktion zum Schreiben in eine Datei )
// ====================================================

int CDfwrite( void* buf, size_t elsize, size_t nelem )
{

    void* CopyBuf = buf;  // Kopierter Savebuffer um Original nicht zu crypten

    // Wir m�ssen eine File offen haben
    if( FileOpened == 0 || FilePointer == NULL )  
    {
        _ERROR( "Error at CDfwrite() in a file!\nNo file opened!" );
         return -1;
    }


    // Filecrypt ausf�hren
    #ifdef ENABLE_CDCRYPT
       if( FileCryptMode == CDCRYPT_BOTH || FileCryptMode == CDCRYPT_WRITE )
       {
           // Original sichern
           if( (nelem*elsize) > 1024 )
           {
              CopyBuf = new char[nelem*elsize];       // Neuen Speicher daf�r anlegen
              memcpy( CopyBuf, buf, (nelem*elsize) );  
           }
           else
           {
               CopyBuf = &CryptBuffer[0];              // Verwendete reserv. Speicher
           }

           Crypt( buf, (nelem*elsize) );    // Verschl�sseln
       }
    #endif


    fwrite( CopyBuf, elsize, nelem, FilePointer );   // Daten schreiben

    // Kopierpuffer l�schen
    if( CopyBuf != buf )
    {
        delete [] CopyBuf;
        CopyBuf = NULL;
    }
    
    return 0;  // Alles ok!

}



// CDfwritestring ( CD-Funktion zum Schreiben eines Strings in eine Datei )
// ========================================================================

int CDfwritestring( String* str, int dontwritenull )
{

    if( FileOpened == 0 || FilePointer == NULL )  // Wir m�ssen eine File offen haben
    {
        _ERROR( "Error at CDwritestring() in a file!\nNo file opened!" );
         return -1;
    }


    for( int i = 0; i < str->length(); i++ )
    {
        CryptBuffer[i] = str->get_at(i);
    }
    CryptBuffer[i] = 0;                                // Endbyte mit 0



    // Filecrypt ausf�hren
    #ifdef ENABLE_CDCRYPT
       if( FileCryptMode == CDCRYPT_BOTH || FileCryptMode == CDCRYPT_READ )
       {
           Crypt( &CryptBuffer[0], str->length() );    // String-Bytes ohne Schluss-0
       }
    #endif



    if( dontwritenull == 0 )
    {
       fwrite( &CryptBuffer[0], 1, str->length()+1, FilePointer );   // Daten schreiben
    }
    else
    {
       fwrite( &CryptBuffer[0], 1, str->length(), FilePointer );     // Daten schreiben ohne NULL-Byte
    }


    return 0;  // Alles ok!
}



// CDfwritereturn ( CD-Funktion um ein Return-Code 0x0D0A in eine Datei zu schreiben )
// ===================================================================================

int CDfwritereturn()
{

    if( FileOpened == 0 || FilePointer == NULL )  // Wir m�ssen eine File offen haben
    {
        _ERROR( "Error at CDwritereturn() in a file!\nNo file opened!" );
         return -1;
    }


    CryptBuffer[0] = 0x0D;
    CryptBuffer[1] = 0x0A;


    // Filecrypt ausf�hren
    #ifdef ENABLE_CDCRYPT
       if( FileCryptMode == CDCRYPT_BOTH || FileCryptMode == CDCRYPT_READ )
       {
           Crypt( &CryptBuffer[0], 2 );
       }
    #endif


    fwrite( &CryptBuffer[0], 1, 2, FilePointer );   // Daten schreiben
    return 0;                                      // Alles ok!
}



// CDfgetc ( CD-Funktion zum Lesen eines Zeichens aus einer Datei )
// ================================================================

int CDfgetc()
{
    char Char = 0;
    CDfread( &Char, 1, 1 );

    return (int) Char;
}



// CDfputc ( CD-Funktion zum Schreiben eines Zeichens in eine Datei )
// ==================================================================

int CDfputc( int c )
{
    char Char = (char) c;
    CDfwrite( &Char, 1, 1 );

    return 0;  // Ok!
}



// CDfeof ( CD-Funktion f�r "feof" )
// =================================

int CDfeof()
{

    // Wir m�ssen eine File offen haben
    if( FileOpened == 0 || FilePointer == NULL )  
    {
        _ERROR( "Error at CDfeof() in a file!\nNo file opened!" );
         return -1;
    }

    return feof( FilePointer );
}



// CDferror ( CD-Funktion f�r "ferror" )
// =====================================

int CDferror()
{

    // Wir m�ssen eine File offen haben
    if( FileOpened == 0 || FilePointer == NULL )  
    {
        _ERROR( "Error at CDferror() in a file!\nNo file opened!" );
         return -1;
    }

    return ferror( FilePointer );
}




